(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f4d93d27._.js",
  "static/chunks/8a611_next_dist_compiled_react-dom_c9d7d9af._.js",
  "static/chunks/8a611_next_dist_compiled_react-server-dom-turbopack_ed2e1e2d._.js",
  "static/chunks/8a611_next_dist_compiled_next-devtools_index_a64ad889.js",
  "static/chunks/8a611_next_dist_compiled_5c831912._.js",
  "static/chunks/8a611_next_dist_client_f4be1637._.js",
  "static/chunks/8a611_next_dist_fa383d43._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
