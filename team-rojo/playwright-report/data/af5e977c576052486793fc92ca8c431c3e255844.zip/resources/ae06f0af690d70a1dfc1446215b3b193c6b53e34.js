(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__72732c49._.css",
  "static/chunks/node_modules__pnpm_1094ba87._.js"
],
    source: "dynamic"
});
