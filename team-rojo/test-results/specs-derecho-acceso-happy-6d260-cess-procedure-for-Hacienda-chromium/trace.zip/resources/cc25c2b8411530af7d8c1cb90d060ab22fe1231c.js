const CLAVE_VALIDATE_URL = "/claveproxy/clave/revalidate?returnUrl=";

const DATE_FORMATTER = Intl.DateTimeFormat(undefined, {
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
});
const DATE_TIME_FORMATTER = Intl.DateTimeFormat(undefined, {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
});


const isEmpty = (val) => {
    return (typeof val === 'string' && val.trim() === '') ||
            val === null ||
            val === undefined ||
            (Array.isArray(val) && val.length === 0) ||
            JSON.stringify(val) === '{}' ||
            val.fileList?.length === 0; // For file inputValues
};

const toBoolean = (val) => {
    return val === 'true' ? true : (val === 'false' ? false : val);
}

const toggleLoadingSpinner = (loadingState, title = '', description = '') => {
    const loadSpinner = document.querySelector('dnt-spinner');
    loadSpinner.titleText = title;
    loadSpinner.description = description;
    loadSpinner.loading = loadingState;
}

const parseDate = (dateString) => {
    // Parser for dates with format: dd/MM/yyyy
    const [day, month, year] = dateString.split('/').map(Number);
    return new Date(year, month - 1, day);
};

const parseDateTime = (dateTimeString) => {
    // Parser for datetimes with format: dd/MM/yyyy H:mm
    const [datePart, timePart] = dateTimeString.trim().split(/\s+/); // splits by any whitespace
    const [day, month, year] = datePart.split("/").map(Number);
    const [hour, minute] = timePart.split(":").map(Number);

    return new Date(year, month - 1, day, hour, minute || 0);
};

const handleMultiplesCondicionesVisibilidad = (elementId, conditionsList, formula, scriptId, isSection) => {
    let element;
    let divContainer;
    if (!isSection) {
        // Search for input element
        const scriptElement = document.getElementById(scriptId);
        divContainer = scriptElement.closest('div.formContainer');

        element = divContainer.querySelector('#' + elementId);
    } else {
        // Search for section element
        element = document.getElementById(elementId);
    }

    // Element hidden by default
    element.hidden = true;
    const isDatePicker = elementId.includes('c18') || elementId.includes('c19') ;
    if(isDatePicker) {
        element.setAttribute('hidden-inputs',true);
    }
        
    

    const datosFormula = {};
    conditionsList.forEach((condition) => {
        // Nos aseguramos de que existe un array para este scriptId
        if (!datosFormula[elementId]) {
            datosFormula[elementId] = [];
        }
        // Inicializamos todas las condiciones a false
        datosFormula[elementId].push({
            orden: condition.orden,
            isValido: false
        })
    });

    let formulaTrad = translateFormula(formula);

    conditionsList.forEach((condition) => {
        // Search inputReference inside div containing the script or else on all document
        const inputReference = divContainer?.querySelector('#' + condition.inputReferenceId) || document.querySelector('#' + condition.inputReferenceId);
        const formControlReference = getFormControl(inputReference);

        formControlReference.addEventListener("changeEvent", function (event) {
            const inputValue = event.detail ?? (event.target?.value || event.target?.extra?.respuesta);

            let isValido = handleVisibilityCondition(condition.conditionType, condition.valueCondition, condition.valueConditionMayor, condition.valueConditionMenor, inputValue);


            // Actualizamos el valor isValido de la condicion validada
            const index = datosFormula[elementId].findIndex(item => item.orden === condition.orden);
            if (index !== -1) {
                datosFormula[elementId][index].isValido = isValido;
            } else {
                console.error("Condition not found!!!!");
            }

            const conditionResultList = datosFormula[elementId];
            const visibilityResult = evaluateFormula(formulaTrad, conditionResultList);
            if (!isSection) {
                handleInputVisibility(element, !visibilityResult);
            } else {
                handleSectionVisibility(element, !visibilityResult);
            }
        });

        // Force trigger changeEvent on first load
        const changeEvent = new Event("changeEvent");
        formControlReference.dispatchEvent(changeEvent);
    });
}

const translateFormula = (formula) => {
    // Filtrar solo los caracteres válidos y reemplazar "Y" por "&&" y "O" por "||"
    const caracteresValidos = formula.match(/[0-9\(\)YO]/g);

    let arrayFormula = caracteresValidos ? caracteresValidos : [];

    let nuevoArray = arrayFormula.map(caracter => {
        if (caracter === "Y") return "&&";
        if (caracter === "O") return "||";
        return caracter;
    });

    //Convertir el array resultante a una fórmula de JavaScript, manteniendo el formato
    const formulaJS = nuevoArray.join('');

    return formulaJS;
};

const evaluateFormula = (formula, conditionResultList) => {
    conditionResultList.forEach(conditionResult => {
        formula = formula.replaceAll(conditionResult.orden, conditionResult.isValido);
    })

    try {
        return eval(formula);
    } catch (error) {
        console.error("Invalid formula: ", error);
        return false;
    }
}

const handleVisibilityCondition = (conditionType, valueCondition, valueConditionMayor, valueConditionMenor, inputValue) => {
    let isCondicion;
    let isDateComparison = false;

    if (valueCondition.includes('/') || valueConditionMayor.includes('/') || valueConditionMenor.includes('/')) {
        isDateComparison = true;
    }

    if (isDateComparison) {
        const inputDate = isNaN(Date.parse(inputValue)) ? null : new Date(inputValue);
        const conditionDate = parseDate(valueCondition);
        const mayorDate = parseDate(valueConditionMayor);
        const menorDate = parseDate(valueConditionMenor);

        if (inputValue === null || inputValue === undefined) {
            isCondicion = false;
        } else {
            switch (conditionType) {
                case "igualA":
                    isCondicion = (inputDate && inputDate.getTime() === conditionDate.getTime());
                    break;
                case "distintoDe":
                    isCondicion = !(inputDate && inputDate.getTime() === conditionDate.getTime());
                    break;
                case "mayorQue":
                    isCondicion = (inputDate && inputDate.getTime() > mayorDate.getTime());
                    break;
                case "menorQue":
                    isCondicion = (inputDate && inputDate.getTime() < menorDate.getTime());
                    break;
                case "entre":
                    isCondicion = (inputDate && inputDate.getTime() <= menorDate.getTime() && inputDate.getTime() >= mayorDate.getTime());
                    break;
                default:
                    isCondicion = true;
                    break;
            }
        }
    } else {
        if (inputValue === null || inputValue === undefined) {
            isCondicion = false;
        } else {
            switch (conditionType) {
                case "igualA":
                    isCondicion = (inputValue == valueCondition);
                    break;
                case "distintoDe":
                    isCondicion = !(inputValue == valueCondition);
                    break;
                case "completo":
                    isCondicion = !isEmpty(inputValue);
                    break;
                case "noCompleto":
                    isCondicion = isEmpty(inputValue);
                    break;
                case "mayorQue":
                    if (inputValue === "" || isNaN(inputValue)) {
                        isCondicion = false;
                    } else {
                        isCondicion = (Number(inputValue) > Number(valueConditionMayor));
                    }
                    break;
                case "menorQue":
                    if (inputValue === "" || isNaN(inputValue)) {
                        isCondicion = false;
                    } else {
                        isCondicion = (Number(inputValue) < Number(valueConditionMenor));
                    }
                    break;
                case "entre":
                    if (inputValue === "" || isNaN(inputValue)) {
                        isCondicion = false;
                    } else {
                        isCondicion = (Number(inputValue) < Number(valueConditionMenor) && Number(inputValue) > Number(valueConditionMayor));
                    }
                    break;
                default:
                    isCondicion = true;
                    break;
            }
        }
    }

    return isCondicion;
};

const handleInputVisibility = (input, isHidden) => {
    // Hides/Shows the input
    input.hidden = isHidden;
    let inputId = input.getAttribute('id');
    if(inputId.includes('c18') || inputId.includes('c19')) {
        input.setAttribute('hidden-inputs',isHidden);
    }

    const isAlreadyCtrl = input.classList.contains('form-control');
    if (isAlreadyCtrl) {
        // Call to handle reset of inputs
        resetHiddenInputs([input], isHidden);
    } else {
        const containedCtrl = input.querySelector('.form-control');
        if (containedCtrl) {
            containedCtrl.hidden = isHidden;

            // Call to handle reset of inputs
            resetHiddenInputs([containedCtrl], isHidden);
        }
    }
};

const handleSectionVisibility = (section, isHidden) => {
    // Hides/Shows the section
    section.hidden = isHidden;

    // Call to handle reset of inputs
    resetHiddenSection(section);
}

const handleSectionVisibilityOld = (sectionId, inputReferenceId, conditionType, valueCondition, valueConditionMayor, valueConditionMenor) => {
    let section = document.getElementById(sectionId);
    section.hidden = true;

    let inputReference = document.getElementById(inputReferenceId);
    inputReference.addEventListener("changeEvent", function (event) {
        const inputValue = event.detail === undefined ?
                                    event.target?.extra?.respuesta :
                                    event.detail;

    let isDateComparison = false;


    if (valueCondition.includes('/') || valueConditionMayor.includes('/') || valueConditionMenor.includes('/')) {
        isDateComparison = true;
    }

    if (isDateComparison) {
        const inputDate = isNaN(Date.parse(inputValue)) ? null : new Date(inputValue);
        const conditionDate = parseDate(valueCondition);
        const mayorDate = parseDate(valueConditionMayor);
        const menorDate = parseDate(valueConditionMenor);


        if (inputValue === null || inputValue === undefined) {
            section.hidden = true;
        } else {
            switch (conditionType) {
                case "igualA":
                    section.hidden = !(inputDate && inputDate.getTime() === conditionDate.getTime());
                    break;
                case "distintoDe":
                    section.hidden = (inputDate && inputDate.getTime() === conditionDate.getTime());
                    break;
                case "mayorQue":
                    section.hidden = !(inputDate && inputDate.getTime() > mayorDate.getTime());
                    break;
                case "menorQue":
                    section.hidden = !(inputDate && inputDate.getTime() < menorDate.getTime());
                    break;
                case "entre":
                    section.hidden = !(inputDate && inputDate.getTime() < menorDate.getTime() && inputDate.getTime() > mayorDate.getTime());
                    break;
                default:
                    section.hidden = false;
                    break;
            }
        }
    } else {
        if (inputValue === null || inputValue === undefined) {
            section.hidden = true;
        } else {
            switch (conditionType) {
                case "igualA":
                    section.hidden = !(inputValue == valueCondition);
                    break;
                case "distintoDe":
                    section.hidden = (inputValue == valueCondition);
                    break;
                case "completo":
                    section.hidden = isEmpty(inputValue);
                    break;
                case "noCompleto":
                    section.hidden = !isEmpty(inputValue);
                    break;
                case "mayorQue":
                    if (inputValue === "" || isNaN(inputValue)) {
                        section.hidden = true;
                    } else {
                        section.hidden = !(Number(inputValue) > Number(valueConditionMayor));
                    }
                    break;
                case "menorQue":
                    if (inputValue === "" || isNaN(inputValue)) {
                        section.hidden = true;
                    } else {
                        section.hidden = !(Number(inputValue) < Number(valueConditionMenor));
                    }
                    break;
                case "entre":
                    if (inputValue === "" || isNaN(inputValue)) {
                        section.hidden = true;
                    } else {
                        section.hidden = !(Number(inputValue) < Number(valueConditionMenor) && Number(inputValue) > Number(valueConditionMayor));
                    }
                    break;
                default:
                    section.hidden = false;
                    break;
            }
        }
    }

        // Call to handle reset of inputs
        resetHiddenSection(section);
    });

    // Force trigger changeEvent on first load
    const changeEvent = new Event("changeEvent");
    inputReference.dispatchEvent(changeEvent);
};

const resetHiddenSection = (section) => {
    if (section) {
        const sectionControls = section.querySelectorAll(".form-control");
        resetHiddenInputs(sectionControls, section.hidden);
    }
}

const resetHiddenInputs = (controlsList, areControlsHidden) => {
    controlsList.forEach(control => {
        if (areControlsHidden) {
            // Cleans values for hidden inputs
            if (control.classList.contains('form-validation-step')) {
                // Reset validation steps to false
                control.value = 'false';
            } else if (control.classList.contains('form-checkbox')) {
                // Clears checkboxes
                control.value = [];
            } else if (control.classList.contains('form-file')) {
                // Clears files
                control.fileList = [];
            } else if (
                control.classList.contains('form-url') ||
                control.classList.contains('form-break') ||
                control.classList.contains('form-textinfo')
            ) {
                // Placeholder to avoid not touchable controls
            } else {
                // Default clearing
                control.value = '';
            }
        } else {
            // Reset to default value for shown inputs

            const defaultValue = control.dataset.defaultValue;
            if (defaultValue) {
                if (control.classList.contains('form-checkbox')) {
                    // Resets checkboxes
                    control.value = JSON.parse(defaultValue);
                } else if (
                    control.classList.contains('form-validation-step') ||
                    control.classList.contains('form-file') ||
                    control.classList.contains('form-url') ||
                    control.classList.contains('form-break') ||
                    control.classList.contains('form-textinfo')
                ) {
                    // Placeholder to avoid not touchable controls
                } else {
                    // Default reset to default value
                    control.value = defaultValue;
                }
            }
        }

        // Force trigger changeEvent after resetting control value
        const changeEvent = new Event("changeEvent");
        control.dispatchEvent(changeEvent);
    });
}

const DocTypes = Object.freeze({
    REQUERIMIENTO: 1,
    REQUERIMIENTO_RESPUESTA: 12,
    RESOLUCION: 2,
    ADJUNTOS_RESOLUCION: 14,
    PRUEBA: 7,
    PRUEBA_RESPUESTA: 13,
    MODIFICACION_PLAZO: 8,
    SEGUIMIENTO: 44,
    SUSPENSION: 9,
    INFORME: 6,
    AUDIENCIA: 3,
    INFORMACION_PUBLICA: 4,
    ALEGACION: 5,
    ALEGACION_RESPUESTA: 28,
    APORTADO_CIUDADANO: 10,
    JUSTIFICANTE_PAGO: 23,
    CERTIFICADO_REPRESENTACION: 24
});

const FormTypes = Object.freeze({
    SOLICITANTE: 1,
    PAGO: 2,
    REPRESENTACION: 4
});

const tipoDocEquivalence = [
    [FormTypes.SOLICITANTE, DocTypes.APORTADO_CIUDADANO],
    [FormTypes.REPRESENTACION, DocTypes.CERTIFICADO_REPRESENTACION],
    [FormTypes.PAGO, DocTypes.JUSTIFICANTE_PAGO]
]
const tipoDocMap = new Map(tipoDocEquivalence);

const uploadFiles = async (fileList, tipoEstructural, idCli) => {
    let idDocumentsList = [];
    const tipoDoc = tipoDocMap.get(tipoEstructural) ?? DocTypes.APORTADO_CIUDADANO;

    for (const file of fileList) {
        let idDocumento;

        if (file.alreadyUploaded) {
            idDocumento = file.idDocumento;
        } else {
            toggleLoadingSpinner(true, "Estamos subiendo tus archivos seleccionados.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

            const fileRaw = file.raw;

            const formData = new FormData();
            formData.append('file', fileRaw);

            try {
                const response = await fetch(contextPath + "/.rest/upload/v1/subirDocumento?" + new URLSearchParams({
                        tipo: tipoDoc,
                        borrador: false,
                        idCliente: idCli
                    }), {
                    method: 'POST',
                    body: formData
                });
                const responseJSON = await response.json();

                toggleLoadingSpinner(false);

                if (responseJSON.hayError || responseJSON.error) {
                    // Throws error on uploading file to server
                    throw {
                        title: 'Se ha producido un error al enviar el archivo',
                        description: responseJSON.mensajeError
                    };
                } else {
                    idDocumento = responseJSON.idDocumento;
                }
            } catch (error) {
                const errorTitle = error.title ?? 'Se ha producido un error al procesar tu solicitud';
                const errorMessage = error.description ?? 'Vuelve a intentarlo más tarde';
                showNotification('error', errorTitle, errorMessage);

                throw new Error(errorTitle);
            }
        }

        idDocumentsList.push(idDocumento);
    };

    console.log("Document IDs: ", idDocumentsList);
    return idDocumentsList;
};

const addDataToElement = (elementId, JSONData, JSONForm, defaultValue) => {
    const extraData = {
        "idFormularioPadre": JSONForm.idPadre,
        "idFormulario": JSONForm.id,
        "idPagina": JSONData.idPagina,
        "idSeccion": JSONData.idSeccion,
        "idCampo": JSONData.id,
        "idTipoCampo": JSONData.idTipoCampo,
        "esEstructural": JSONForm.esEstructural,
        "tipoEstructural": JSONForm.tipoEstructural,
        "etiquetaCampo": JSONForm.id + "_" + JSONData.etiquetaCampoAux,
        "etiquetaCampoAux": JSONData.etiquetaCampoAux,
        "respuesta": defaultValue || "",
        "numRepeticion": 1
    };
    const input = document.getElementById(elementId);
    if (input) {
        input.extra = extraData;
    }
};

const addRepetitionDataToElement = (elementId, repetitiontValues) => {
    const input = document.getElementById(elementId);
    if (input && repetitiontValues) {
        input.repetitionData = repetitiontValues;
    }
};

const removeScript = (scriptId) => {
    const selfScript = document.getElementById(scriptId);
    selfScript.remove();
};

const toggleModal = (modalId, visible = true) => {
    const modal = document.querySelector('#' + modalId);
    modal.setAttribute('visible', visible);
}

const closeModal = (modalId) => {
    toggleModal(modalId, false);
};

const showNotification = (type, title, message) => {
    toast({
        titleText: title ?? '',
        message: message ?? '',
        type: type,
        customClass: 'customToast',
        position: 'top-right',
        lang: 'es',
        zIndex: 100
    });
};

const blobToFile = (blobData, filename) => {
    const newFile = new File([blobData], filename, {
        type: blobData.type
    });
    return newFile;
};

const visualizarBase64PDF = (base64String) => {
  try {
    const mediaType = detectarMediaTypeBase64(base64String);

    const byteCharacters = atob(base64String);
    const byteNumbers = Array.from(byteCharacters, c => c.charCodeAt(0));
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: mediaType  });

    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, "_blank");
  } catch (err) {
    console.error("Error mostrando el PDF base64:", err);
    alert("No se pudo visualizar el documento.");
  }
};

const detectarMediaTypeBase64 = (base64String) => {
  try {
    // Detectar PDF por prefijo Base64
    if (base64String.startsWith("JVBE")) {
      return "application/pdf";
    }

    const byteCharacters = atob(base64String);
    const bytes = [];
    for (let i = 0; i < 8 && i < byteCharacters.length; i++) {
      bytes.push(byteCharacters.charCodeAt(i));
    }

    // PNG
    if (
      bytes.length >= 8 &&
      bytes[0] === 0x89 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x4E &&
      bytes[3] === 0x47 &&
      bytes[4] === 0x0D &&
      bytes[5] === 0x0A &&
      bytes[6] === 0x1A &&
      bytes[7] === 0x0A
    ) {
      return "image/png";
    }

    // JPEG
    if (
      bytes.length >= 3 &&
      bytes[0] === 0xFF &&
      bytes[1] === 0xD8 &&
      bytes[2] === 0xFF
    ) {
      return "image/jpeg";
    }

    // GIF
    if (
      bytes.length >= 6 &&
      byteCharacters.startsWith("GIF87a") || byteCharacters.startsWith("GIF89a")
    ) {
      return "image/gif";
    }

    // ZIP (docx, xlsx, pptx)
    if (
      bytes.length >= 4 &&
      bytes[0] === 0x50 &&
      bytes[1] === 0x4B &&
      bytes[2] === 0x03 &&
      bytes[3] === 0x04
    ) {
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    }

    return "application/octet-stream";
  } catch {
    return "application/octet-stream";
  }
};

const downloadDocument = async (idDocumento, tipoDocumento) => {
    try {
        toggleLoadingSpinner(true, "Descargando documento...");

        const params = "?id=" + idDocumento + "&tipoDocumento=" + tipoDocumento;
        const response = await fetch(contextPath + "/.rest/download/v1/descargaDocumento" + params);
        toggleLoadingSpinner(false);

        console.log(response);
        if (!response.ok) {
            throw new Error(response);
        }
        const blob = await response.blob();

        return blobToFile(blob, "SOLICITUD_" + idDocumento + ".pdf");
    } catch (error) {
        toggleLoadingSpinner(false);
        console.error('Failed to download file', error);
        throw new Error(error);
    }
};

const getCookie = (cname) => {
    let name = cname + "=";
    let ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return null;
};

const setCookie = (cname, cvalue, exdays) => {
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
};

const addPaginationListener = () => {
    pagination = document.querySelector('#pagination');
    pagination.addEventListener("currentChange", function(event) {
        toggleLoadingSpinner(true, "Cargando resultados...");

        const url = new URL(window.location.href);
        url.searchParams.set('p', event.detail);
        window.location.href = url.toString();
    });
};

const cloneJSON = (object) => {
    return JSON.parse(JSON.stringify(object));
};

const handleSpecialInputs = (originalInput, clonedInput) => {
    if (originalInput.classList.contains('form-file')) {
        // Clonado para FileUploader
        const fileUploaderClone = originalInput.cloneNode();

        let fileUploaderButton = document.createElement('dnt-button');
        fileUploaderButton.innerText = 'Seleccionar archivo';
        fileUploaderButton.setAttribute('type', 'primary-light');
        fileUploaderButton.setAttribute('size', 'm');
        fileUploaderButton.setAttribute('icon', 'Upload');
        fileUploaderButton.setAttribute('icon-position', 'left');

        const fileUploaderTip = originalInput.querySelector('.dnt-file-uploader__tip').cloneNode(true);

        fileUploaderClone.appendChild(fileUploaderButton);
        fileUploaderClone.appendChild(fileUploaderTip);

        addFileUploaderEvents(fileUploaderClone);

        clonedInput = fileUploaderClone;

    } else if (originalInput.classList.contains('form-radio')) {
        // Clonado para RadioGroup
        const radioClone = originalInput.cloneNode();

        const radioOptions = originalInput.querySelectorAll('dnt-radio');
        radioOptions.forEach(option => {
            const optionClone = option.cloneNode();
            //optionClone.innerText = option.querySelector('span.dnt-radio__label').innerText;
            optionClone.innerHTML = option.outerText;
            radioClone.appendChild(optionClone);
        })

        clonedInput = radioClone;
    }

    return clonedInput;
};

const elementsRepeats = (elementId, inputReferenceId, scriptId) => {
    let divContainer = document;
    if (scriptId) {
        const scriptElement = document.getElementById(scriptId);
        divContainer = scriptElement.closest('div.formContainer');

        if (divContainer.dataset.original) {
            console.warn("Element: " + elementId);
            return;
        }
    }

    // Search inputReference inside div containing the script or else on all document
    let inputReference = divContainer.querySelector('#' + inputReferenceId) || document.querySelector('#' + inputReferenceId);
    let originalElement = divContainer.querySelector('#' + elementId);
    let previousInput = inputReference.value;
    if (previousInput === undefined) {
        previousInput = 0;
    }

    inputReference.addEventListener("changeEvent", function (event) {
        let inputValue = event.detail ?? (event.target?.value || event.target?.extra?.respuesta);

        inputValue = (inputValue > 10) ? 10 : inputValue;

        // Elemento original siempre escondido
        originalElement.hidden = true;
        if(originalElement.id.includes('c18') || originalElement.id.includes('c19')) {
            originalElement.setAttribute('hidden-inputs',true);
        }

        // Función crear elemento
        const createElement = (numRepeticion) => {
            const isSection = originalElement.classList.contains('formContainer');
            const isBlock = originalElement.classList.contains('form-block');
            let clonedElement = originalElement.cloneNode(true);

            if (isSection) {
                // Clonamos sección
                const originalControls = originalElement.querySelectorAll('.form-control');
                const clonedControls = clonedElement.querySelectorAll('.form-control');

                for (let index = 0; index < originalControls.length; index++) {
                    const originalCtrl = originalControls[index];
                    const clonedCtrl = clonedControls[index];

                    const clonedCtrlFixed = handleSpecialInputs(originalCtrl, clonedCtrl);
                    clonedCtrl.replaceWith(clonedCtrlFixed);

                    if (originalCtrl.extra) {
                        clonedCtrlFixed.extra = cloneJSON(originalCtrl.extra);
                        clonedCtrlFixed.extra.numRepeticion = numRepeticion; // Núm. Rep. de sección
                    }

                    if (originalCtrl.repetitionData) {
                        const previousRepetitionValue = originalCtrl.repetitionData.find(item => Number(item.numRepeticion) === numRepeticion);

                        if (previousRepetitionValue) {
                            recoverCtrlPreviousRepetitionValue(clonedCtrlFixed, previousRepetitionValue);
                        } else {
                            // Call to handle reset of inputs
                            resetHiddenInputs([clonedCtrlFixed], true);
                        }
                    }

                    if (clonedCtrlFixed.type === 'date') {
                        clonedCtrlFixed.addEventListener('invalidFormat', function () {
                            clonedCtrlFixed.setAttribute('status', 'error');
                            clonedCtrlFixed.setAttribute('error-message', 'La fecha seleccionada no contiene un formato correcto');
                        });

                        clonedCtrlFixed.addEventListener('changeEvent', function () {
                            const isValid = evalDateFormatControl(clonedCtrlFixed);

                            if (isValid) {
                                clonedCtrlFixed.setAttribute('status', 'default');
                                clonedCtrlFixed.removeAttribute('error-message');
                            }
                        });
                    }

                    if (clonedCtrlFixed.id) {
                        const originalId = clonedCtrlFixed.id;
                        clonedCtrlFixed.id = `${clonedCtrlFixed.id}_${numRepeticion}`;

                        // Actualizar ID en scripts asociados dentro del bloque
                        const clonedScripts = clonedElement.querySelectorAll('script');

                        clonedScripts.forEach(clonedScript => {
                            const scriptContent = clonedScript.innerHTML;

                            if (scriptContent.includes(originalId)) {
                                clonedScript.innerHTML = clonedScript.innerHTML.replaceAll(originalId, clonedCtrlFixed.id);
                            }
                        });
                    }

                    // Añadimos evento para validación de campos onChange
                    clonedCtrlFixed.addEventListener("changeEvent", event => {
                        evalValidControl(clonedCtrlFixed);
                    });

                    originalCtrl.hidden = true;
                    if (originalCtrl.id.includes('c18') || originalCtrl.id.includes('c19')) {
                        originalCtrl.setAttribute('hidden-inputs',true);
                    }
                    clonedCtrlFixed.hidden = false;
                    if (clonedCtrlFixed.id.includes('c18') || clonedCtrlFixed.id.includes('c19')) {
                        clonedCtrlFixed.setAttribute('hidden-inputs',false);
                    }
                }

                // Actualizar el título de la sección clonada
                const titleElement = clonedElement.querySelector('.dnt-txt-subtitle-200');
                if (titleElement) {
                    titleElement.textContent = `${titleElement.textContent} ${numRepeticion}`;
                }
            } else {
                // Clonamos Form Control/Input (también los campos tipo Block, que contiene varios Controls/Inputs)
                const isFormControl = (element) => element.classList.contains('form-control');
                const isFormTextInfo = (element) => element.classList.contains('form-textinfo');

                const isAlreadyCtrl = isFormControl(originalElement) || isFormTextInfo(originalElement);

                let originalControls = [];
                let clonedControls = [];

                if (isBlock) {
                    // Form Controls/Inputs dentro de un campo tipo Block
                    originalControls = originalElement.querySelectorAll('.form-control');
                    clonedControls = clonedElement.querySelectorAll('.form-control');
                } else {
                    // Form Control/Input individual
                    originalControls = isAlreadyCtrl
                        ? [originalElement]
                        : [originalElement.querySelector('.form-control, .form-textinfo')];
                    clonedControls = isAlreadyCtrl
                        ? [clonedElement]
                        : [clonedElement.querySelector('.form-control, .form-textinfo')];
                }

                for (let index = 0; index < originalControls.length; index++) {
                    const originalCtrl = originalControls[index];
                    const clonedCtrl = clonedControls[index];

                    if (originalCtrl && clonedCtrl) {
                        const clonedCtrlFixed = handleSpecialInputs(originalCtrl, clonedCtrl);

                        // Sustituimos elemento clonado por el fixeado para campos especiales
                        isAlreadyCtrl ?
                            clonedElement = clonedCtrlFixed :
                            clonedElement.replaceChild(clonedCtrlFixed, clonedCtrl);

                        if (originalCtrl.extra) {
                            const currentSection = document.querySelector("[id$='s" + originalCtrl.extra.idSeccion + "']");
                            clonedCtrlFixed.extra = cloneJSON(originalCtrl.extra);
                            let originalNumRepeticion;
                            if (currentSection.getAttribute("copia")) {
                                originalNumRepeticion = originalCtrl.extra.numRepeticion;
                            }
                            const originalCtrl_NumSection = originalNumRepeticion ? String(originalNumRepeticion)[0] : '';
                            clonedCtrlFixed.extra.numRepeticion = originalCtrl_NumSection + numRepeticion; // Núm. Rep. de sección + Núm. Rep. de campo
                        }

                        if (originalCtrl.repetitionData) {
                            const previousRepetitionValue = originalCtrl.repetitionData.find(item => Number(item.numRepeticion) === numRepeticion);

                            if (previousRepetitionValue) {
                                recoverCtrlPreviousRepetitionValue(clonedCtrlFixed, previousRepetitionValue);
                            } else {
                                // Call to handle reset of inputs
                                resetHiddenInputs([clonedCtrlFixed], true);
                            }
                        }

                        if (clonedCtrlFixed.type === 'date') {
                            clonedCtrlFixed.addEventListener('invalidFormat', function () {
                                clonedCtrlFixed.setAttribute('status', 'error');
                                clonedCtrlFixed.setAttribute('error-message', 'La fecha seleccionada no contiene un formato correcto');
                            });

                            clonedCtrlFixed.addEventListener('changeEvent', function () {
                                const isValid = evalDateFormatControl(clonedCtrlFixed);

                                if (isValid) {
                                    clonedCtrlFixed.setAttribute('status', 'default');
                                    clonedCtrlFixed.removeAttribute('error-message');
                                }
                            });
                        }

                        if (clonedCtrlFixed.id) {
                            const originalId = clonedCtrlFixed.id;
                            clonedCtrlFixed.id = `${clonedCtrlFixed.id}_${numRepeticion}`;

                            // Actualizar ID en scripts asociados
                            const clonedScripts = clonedElement.querySelectorAll('script');

                            clonedScripts.forEach(clonedScript => {
                                const scriptContent = clonedScript.innerHTML;

                                if (scriptContent.includes(originalId)) {
                                    clonedScript.innerHTML = clonedScript.innerHTML.replaceAll(originalId, clonedCtrlFixed.id);
                                }
                            });
                        }

                        if (!isBlock) {
                            // Actualizar el nombre del control clonado (añadiendo numRepeticion)
                            if (clonedCtrlFixed.label) {
                                clonedCtrlFixed.label = `${clonedCtrlFixed.label} ${numRepeticion}`;
                            }

                            if (clonedCtrlFixed.selectLabel) {
                                clonedCtrlFixed.selectLabel = `${clonedCtrlFixed.selectLabel} ${numRepeticion}`;
                            }

                            if (clonedCtrlFixed.inputLabel) {
                                clonedCtrlFixed.inputLabel = `${clonedCtrlFixed.inputLabel} ${numRepeticion}`;
                            }

                            // Actualizar textContent de elementos con la clase form-textinfo
                            if (isFormTextInfo(originalCtrl)) {
                                clonedCtrlFixed.textContent = `${originalCtrl.textContent} ${numRepeticion}`;
                            }
                        }

                        // Añadimos evento para validación de campos onChange
                        clonedCtrlFixed.addEventListener("changeEvent", event => {
                            evalValidControl(clonedCtrlFixed);
                        });

                        originalCtrl.hidden = true;
                        if(originalCtrl.id.includes('c18') || originalCtrl.id.includes('c19')) {
                            originalCtrl.setAttribute('hidden-inputs',true);
                        }
                        clonedCtrlFixed.hidden = false;
                        if(clonedCtrlFixed.id.includes('c18') || clonedCtrlFixed.id.includes('c19')) {
                            clonedCtrlFixed.setAttribute('hidden-inputs',false);
                        }
                    }
                }
            }

            // Fix cloning scripts tags
            const originalScripts = originalElement.querySelectorAll('script');
            const clonedScripts = clonedElement.querySelectorAll('script');

            originalScripts.forEach((originalScript, index) => {
                const clonedScript = clonedScripts[index];
                
                const isScriptRepeat = originalScript.id.includes("scriptRepeat");
                if (isBlock && isScriptRepeat) {
                    // Removes cloned Repeat scripts inside Blocks
                    originalScript.remove();
                    clonedScript.remove();
                } else {
                    let newScript = document.createElement('script');

                    if (originalScript.id) {
                        newScript.id = `${originalScript.id}_${numRepeticion}`;
                        newScript.innerHTML = clonedScript.innerHTML.replaceAll(originalScript.id, newScript.id);

                        clonedScript.parentNode.insertBefore(newScript, clonedScript);
                        clonedScript.remove();
                    }
                }
            });

            delete clonedElement.dataset.original;
            clonedElement.setAttribute("copia", "true");
            // Insertamos la sección duplicada antes de la sección original
            originalElement.parentNode.insertBefore(clonedElement, originalElement);

            clonedElement.hidden = false;
            if (clonedElement.id.includes('c18') || clonedElement.id.includes('c19')) {
                originalElement.setAttribute('hidden-inputs',true);
            }
        }

        // Eliminamos las secciones duplicadas anteriores
        const removeElement = () => {
            let previousSibling = originalElement.previousSibling;
            let copia = previousSibling?.getAttribute?.("copia");
            if (copia) {
                previousSibling.remove();
            }
        };

        // Le damos valor 0 a la variable inputValue si esta es menor que 0.
        if (inputValue < 0) {
            inputValue = 0;
        }
        // Calculamos la diferencia entre el valor actual y el anterior
        let difference = inputValue - previousInput;
        let previousRepetition = previousInput;
        
        // Actualizamos el valor anterior de repeticiones (antes de crear o eliminar para evitar loops)
        previousInput = inputValue;

        // Si la diferencia es positiva, creamos nuevos elementos
        if (difference > 0) {
            for (let i = previousRepetition; i < inputValue; i++) {
                const numRepeticion = Number(i) + 1;
                createElement(numRepeticion);
            }
        }
        // Si la diferencia es negativa, eliminamos elementos anteriores
        else if (difference < 0) {
            for (let i = 0; i < -difference; i++) {
                removeElement();
            }
        }
    });

    // Force trigger change event on first load
    const changeEvent = new Event("changeEvent");
    inputReference.dispatchEvent(changeEvent);
};

const recoverCtrlPreviousRepetitionValue = (formControl, previousRepetitionValue) => {
    switch (formControl?.extra?.idTipoCampo) {
        case 6:
            // Parsear valor con formato específico en campos tipo Checkbox
            const activeCheckboxValue = previousRepetitionValue.respuesta.split("; ");
            formControl.value = activeCheckboxValue;
            break;
        case 8:
            // Parsear valores en campos tipo Subir documento
            const filesUploadedIdList = previousRepetitionValue.respuesta.split("; ");
            const filesUploadedNameList = previousRepetitionValue.nombreDoc.split("; ");
            const filesUploadedExtensionList = previousRepetitionValue.extension.split("; ");

            const previousFilesUploaded = [];
            filesUploadedIdList.forEach((fileUploadedId, index) => {
                previousFilesUploaded.push({
                    idDocumento: fileUploadedId,
                    name: filesUploadedNameList[index] + "." + filesUploadedExtensionList[index],
                    status: "success",
                    alreadyUploaded: true,
                    url: contextPath + "/.rest/download/v1/descargaDocumento?id=" + fileUploadedId + "&tipoDocumento=docBorrador"
                });
            });
            formControl.fileList = previousFilesUploaded;
            break;
        case 18:
            // Parsear valor con formato específico en campos tipo Fecha
            const onlyDate = previousRepetitionValue.respuesta.split(" ")[0];
            const parsedDate = parseDate(onlyDate);
            formControl.value = parsedDate;
            break;
        case 19:
            // Parsear valor con formato específico en campos tipo Fecha/Hora
            const parsedDateTime = parseDateTime(previousRepetitionValue.respuesta);
            formControl.value = parsedDateTime;
            break;
    
        default:
            formControl.value = previousRepetitionValue.respuesta;
            break;
    }
}

const validateDates = () => {
    const fechaIni = document.getElementById('filtroFechaIni');
    const fechaFin = document.getElementById('filtroFechaFin');

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const startDate = new Date(fechaIni.value);
    const endDate = new Date(fechaFin.value);

    // Valida si la fecha de inicio es posterior a la de hoy
    if (startDate > today) {
        fechaIni.setAttribute('status', 'error');
    } else {
        fechaIni.setAttribute('status', 'default');
    }

    // Valida si la fecha de fin es anterior a la de inicio
    if (fechaIni.value && fechaFin.value) {
        if (endDate < startDate) {
            fechaFin.setAttribute('status', 'error');
        } else {
            fechaFin.setAttribute('status', 'default');
        }
    } else if (!fechaFin.value) {
        // Si el campo de fecha fin está vacío, restablecer el estado
        fechaFin.setAttribute('status', 'default');
    }
};

const getMensajeError = (codigoError) => {
    // Buscar en el array de messageErrors por el codigoError y si se encuentra, devuelve 'mensajeMostrar'
    if (typeof messageErrors !== 'undefined') {
        return messageErrors?.find(error => error.name == codigoError)?.mensajeMostrar;
    }
    return null;
};

const normalizeString = (str) => {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

const pollStatus = async (endpoint, instancia, interval = 15 * 1000, maxDuration = 5 * 60 * 1000) => {
    const startTime = Date.now();

    while (Date.now() - startTime < maxDuration) {
        // Wait before making the next status check
        await new Promise((res) => setTimeout(res, interval));

        const postBody = new URLSearchParams();
        postBody.append("instancia", instancia);

        const statusResponse = await fetch(contextPath + "/.rest/consultaEstado/v1/" + endpoint, {
            method: "POST",
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            body: postBody,
        });

        if (!statusResponse.ok) {
            throw new Error(`checkStatus error: ${statusResponse.status}`);
        }

        const statusData = await statusResponse.json();
        console.log("Status:", statusData);

        // Check procesando condition
        if (!statusData.procesando) {
            console.log("Process completed successfully!");
            return statusData;
        }
    }

    throw new Error("Timeout: Process did not complete within max duration");
}
