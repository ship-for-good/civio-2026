const evaluateValidForm = (element) => {
    const formControls = element.querySelectorAll('div.formContainer:not([hidden]) .form-control:not([hidden])');
    let isValidForm = true;

    const windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    const halfWindowHeight = windowHeight / 2;

    // Almacenamos la posición del primer campo no válido
    let firstInvalidFieldPosition = null;

    // Validación de campos
    formControls.forEach(control => {
        console.log(control.label + ' ' + control.required + ' ' + control.value);

        const isControlValid = evalValidControl(control);

        if (!isControlValid && !firstInvalidFieldPosition) {
            // Almacena la posición del primer campo no válido
            firstInvalidFieldPosition = control.getBoundingClientRect().top + window.scrollY;
        }

        isValidForm = isControlValid && isValidForm;
    });

    // Validar que solicitante y representado no son la misma persona
    const docRepresentado = document.querySelectorAll("[data-type^='idRepresentado']");
    docRepresentado.forEach(control => {
        let isRepreDif = comprobarDiferenteRepresentado();
        if (!isRepreDif) {
            control.setAttribute('status', 'error');
            control.setAttribute('error-message', 'Solicitante y representado deben ser diferentes personas.');
        }

        isValidForm = isRepreDif && isValidForm;

    });

    // Validación de pasos adicionales
    const formValidationSteps = element.querySelectorAll("div.formContainer:not([hidden]) .form-validation-step");
    formValidationSteps.forEach(validationStep => {
        console.log("Validation Step " + validationStep.id + " => " + validationStep.value);

        if (validationStep.required) {
            const isValidationStepValid = evalValidationStep(validationStep);
            isValidForm = isValidForm && isValidationStepValid;
        }
    });

    // Si hay campos no válidos, hacemos scroll hasta el primero
    if (!isValidForm && firstInvalidFieldPosition) {
      window.scrollTo({
          top: firstInvalidFieldPosition - halfWindowHeight,
          behavior: "smooth"
      });
  }

    return isValidForm;
}

const evalValidControl = (control) => {
    let isControlValid = true;
    if (control.required) {
        console.log('Change Required ' + control.label);
        isControlValid = isControlValid && evalRequiredControl(control);
    }

    if (control.pattern && (control.required || !isEmpty(control.value))) {
        console.log('Change Pattern ' + control.label);
        isControlValid = isControlValid && evalRegexControl(control);
    }

    // Validar campo de tipo 'date'
    if (control.type === 'date') {
        // Comprobar si el estado es 'error'
        if (control.getAttribute('status') === 'error') {
            console.log('Date field has error status: ' + control.label);
            isControlValid = false;
        } else if (!isEmpty(control.value)) {
            console.log('Validating date format for: ' + control.label);
            isControlValid = isControlValid && evalDateFormatControl(control);
        }
    }

    if (control.dataset.fechaDesde && control.dataset.fechaHasta) {
        console.log('Validating date field between: ' + control.label);
        isControlValid = isControlValid && evalDateBetweenControl(control);
    }

    if (control.dataset.fechaMenorIgualHoy) {
        console.log('Validating date field today: ' + control.label);
        isControlValid = isControlValid && evalDateTodayControl(control);
    }

    // Validar campo de tipo 'datetime'
    if (control.type === 'datetime') {
        // Comprobar si el estado es 'error'
        if (control.getAttribute('status') === 'error') {
            console.log('DateTime field has error status: ' + control.label);
            isControlValid = false;
        } else if (!isEmpty(control.value)) {
            console.log('Validating datetime format for: ' + control.label);
            isControlValid = isControlValid && evalDateTimeFormatControl(control);
        }
    }

    if (control.dataset.fechaHoraDesde || control.dataset.fechaHoraHasta) {
        console.log('Validating date field between: ' + control.label);
        isControlValid = isControlValid && evalDateTimeBetweenControl(control);
    }

    // Validar campo tipo NIF/NIE/CIF (case 15)
    if (control.id.includes('c15') && !isEmpty(control.value)) {

        let isNifSolicitante = false;
        if (control.dataset.type === "nifSolicitante") {
            isNifSolicitante = true;
        }

        isControlValid = isControlValid && validateID(control.value, isNifSolicitante);
        if (isControlValid) {
            control.setAttribute('status', 'default');

        } else {
            control.setAttribute('status', 'error');
            control.setAttribute('error-message', 'El campo no tiene NIF/NIE/CIF válido.');
        }
    }

    // Validar campo tipo NIF (case 39)
    if (control.id.includes('c39') && !isEmpty(control.value)) {
        isControlValid = isControlValid && validateNIF(control.value);
        if (!isControlValid) {
            control.setAttribute('status', 'error');
            control.setAttribute('error-message', 'El campo no tiene un NIF válido.');
        }
    }

     // Validar campo tipo NIE (case 40)
     if (control.id.includes('c40') && !isEmpty(control.value)) {
        isControlValid = isControlValid && validateNIE(control.value);
        if (!isControlValid) {
            control.setAttribute('status', 'error');
            control.setAttribute('error-message', 'El campo no tiene un NIE válido.');
        }
    }

    // Validar campo tipo CIF (case 41)
    if (control.id.includes('c41') && !isEmpty(control.value)) {
        isControlValid = isControlValid && validateCIF(control.value);
        if (!isControlValid) {
            control.setAttribute('status', 'error');
            control.setAttribute('error-message', 'El campo no tiene un CIF válido.');
        }
    }

    //Validar campo tipo IBAN (case 16)
    if (control.id.includes('c16') && !isEmpty(control.value)) {
        isControlValid = isControlValid && validateIBAN(control.value);
        if (!isControlValid) {
            control.setAttribute('status', 'error');
            control.setAttribute('error-message', 'El campo no tiene un IBAN válido.');
        }
    }

 //eliminar cualquier elemento que no sea unicode
    if ( (control.id.includes('c1_')  || control.id.includes('c2_'))&& !isEmpty(control.value)) {
        const regex = /^[\u0000-\uFFFF]$/;
        
        let filteredText = '';

        for (const char of control.value) {
            if (regex.test(char)) {
                filteredText += char; 
            }
        }

        control.value=filteredText;
    }


    if (isControlValid) {
        control.status = "default";
    }

    return isControlValid;
}

const evalRequiredControl = (control) => {
    if (isFileInput(control)) {
        return evalFileControl(control);
    }
    if (!isFileInput(control) && isEmpty(control.value)) {
        control.errorMessage = "Este campo es obligatorio";
        control.status = "error";
        return false;
    }
    control.status = "default";
    return true;
}

const evalRegexControl = (control) => {
    const regExp = new RegExp(control.pattern);
    if (!isFileInput(control) && !regExp.test(control.value)) {
        control.errorMessage = control.dataset.validationMessage;
        control.status = "error";
        return false;
    }
    control.status = "default";
    return true;
}

const evalFileControl = (control) => {
    if (control.fileList.length <= 0) {
        toggleFileUploaderError(control, true, "Es obligatorio adjuntar un archivo");
        return false;
    }
    toggleFileUploaderError(control, false);
    return true;
}

const evalDateBetweenControl = (control) => {
    const fechaDesde = new Date(control.dataset.fechaDesde);
    const fechaHasta = new Date(control.dataset.fechaHasta);
    const fechaIngresada = new Date(control.value);

    // Normalizamos las fechas a YYYY-MM-DD sin horas
    const fechaDesdeNormalized = new Date(fechaDesde.getFullYear(), fechaDesde.getMonth(), fechaDesde.getDate());
    const fechaHastaNormalized = new Date(fechaHasta.getFullYear(), fechaHasta.getMonth(), fechaHasta.getDate());
    const fechaIngresadaNormalized = new Date(fechaIngresada.getFullYear(), fechaIngresada.getMonth(), fechaIngresada.getDate());

    if (fechaIngresadaNormalized < fechaDesdeNormalized || fechaIngresadaNormalized > fechaHastaNormalized) {
        control.status = "error";
        control.errorMessage = "La fecha introducida no se encuentra dentro del rango establecido";
        return false;
    }

    control.status = "default";
    return true;
};

const evalDateTimeBetweenControl = (control) => {
    const fechaDesde = new Date(control.dataset.fechaHoraDesde);
    const fechaHasta = new Date(control.dataset.fechaHoraHasta);
    const fechaIngresada = new Date(control.value);

    // Normalizamos las fechas a YYYY-MM-DD sin horas
    const fechaDesdeNormalized = new Date(fechaDesde.getUTCFullYear(), fechaDesde.getUTCMonth(), fechaDesde.getUTCDate(), fechaDesde.getUTCHours(), fechaDesde.getUTCMinutes(), fechaDesde.getUTCSeconds());
    const fechaHastaNormalized = new Date(fechaHasta.getUTCFullYear(), fechaHasta.getUTCMonth(), fechaHasta.getUTCDate(), fechaHasta.getUTCHours(), fechaHasta.getUTCMinutes(), fechaHasta.getUTCSeconds());
    const fechaIngresadaNormalized = new Date(fechaIngresada.getFullYear(), fechaIngresada.getMonth(), fechaIngresada.getDate(), fechaIngresada.getHours(), fechaIngresada.getMinutes());

    if (fechaIngresadaNormalized < fechaDesdeNormalized || fechaIngresadaNormalized > fechaHastaNormalized) {
        control.status = "error";
        control.errorMessage = "La fecha y hora introducidas no se encuentran dentro del rango establecido";
        return false;
    }

    control.status = "default";
    return true;
};

const evalDateTodayControl = (control) => {
    const fechaHoy = new Date();
    const fechaIngresada = new Date(control.value);
    fechaHoy.setHours(0, 0, 0, 0);

    if (control.dataset.fechaMenorIgualHoy === "true" && fechaIngresada > fechaHoy) {
        control.status = "error";
        control.errorMessage = "La fecha introducida no puede ser posterior al día de hoy";
        return false;
    }
    control.status = "default";
    return true;
};

const invalidDateFormat = (idCampo) => {
    const datePicker = document.getElementById(idCampo);

    datePicker.addEventListener('invalidFormat', function () {
        datePicker.setAttribute('status', 'error');
        datePicker.setAttribute('error-message', 'La fecha seleccionada no contiene un formato correcto');
    });

    let isValid;

    datePicker.addEventListener('changeEvent', function () {
        if(idCampo.includes('c18')) {
            isValid= evalDateFormatControl(datePicker);
        } 
        
        if(idCampo.includes('c19')) {
            isValid = evalDateTimeFormatControl(datePicker);
        }
        
        if (isValid) {
            // Si el formato es válido, restablece el estado a "default"
            datePicker.setAttribute('status', 'default');
            datePicker.removeAttribute('error-message');
        }
    });
};

const evalDateFormatControl = (control) => {
    const dateValue = control.value;

    const dateObject = new Date(dateValue);
    const day = String(dateObject.getDate()).padStart(2, '0');
    const month = String(dateObject.getMonth() + 1).padStart(2, '0');
    const year = dateObject.getFullYear();

    // Formatea la fecha en DD/MM/YYYY
    const formattedDate = `${day}/${month}/${year}`;
    console.log('Fecha formateada: ' + formattedDate);

    // Expresión regular para validar formato de fecha DD/MM/YYYY
    const regex = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/([12][0-9]{3})$/;
    const isValidFormat = regex.test(formattedDate);

    return isValidFormat;
};

const evalDateTimeFormatControl = (control) => {
    const dateValue = control.value;

    const dateObject = new Date(dateValue);
    const day = String(dateObject.getDate()).padStart(2, '0');
    const month = String(dateObject.getMonth() + 1).padStart(2, '0');
    const year = dateObject.getFullYear();
    const hour = String(dateObject.getHours()).padStart(2, '0');
    const minutes= String(dateObject.getMinutes()).padStart(2, '0'); 

    // Formatea la fecha en DD/MM/YYYY HH:MM
    const formattedDate = `${day}/${month}/${year} ${hour}:${minutes}`;
    console.log('Fecha formateada: ' + formattedDate);

    // Expresión regular para validar formato de fecha DD/MM/YYYY HH:MM
    const regex = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/([12][0-9]{3}) ([01][0-9]|2[0-3]):[0-5][0-9]$/;
    const isValidFormat = regex.test(formattedDate);

    return isValidFormat;
};

const toggleFileUploaderError = (fileUploader, showError, errorMessageTxt) => {
    const fileUploaderTip = fileUploader.querySelector(".dnt-file-uploader__tip");
    let errorBlock = fileUploaderTip.querySelector('div.dnt-file-uploader__error');

    if (showError) {
        if (!errorBlock) {
            errorBlock = document.createElement("div");
            errorBlock.className = "dnt-file-uploader__error text-status-error dnt-flex dnt-items-center dnt-txt-body-100 dnt-gap-2 dnt-mt-2";
            const errorIcon = document.createElement("dnt-icon");
            errorIcon.size = "16";
            errorIcon.name = "Status-Error";
            errorBlock.appendChild(errorIcon);
            const errorMessage = document.createElement("span");
            errorMessage.innerText = errorMessageTxt;
            errorBlock.appendChild(errorMessage);

            fileUploaderTip.appendChild(errorBlock);
        }
    } else {
        errorBlock?.remove();
    }
};

const isFileInput = (control) => {
    return control.classList.contains("form-file");
};

const evalValidationStep = (validationStep) => {
    const isValidStep = toBoolean(validationStep.value);
    if (!isValidStep) {
        const errorMessage = validationStep.errorMessage || "Existen errores en el formulario"
        showNotification('error', errorMessage);
    }

    return isValidStep;
}

const compareInputsValidation = (inputOrigin, inputCompare, errorMessage) => {
    // Validate password vs confirm password
    if (inputOrigin.value !== inputCompare.value) {
        inputCompare.errorMessage = errorMessage;
        inputCompare.status = "error";
        return false;
    } else {
        inputCompare.status = "success";
        return true;
    }
}

const getFormControl = (inputElement) => {
    const isAlreadyCtrl = inputElement.classList.contains('form-control');
    if (!isAlreadyCtrl) {
        // InputElement is NOT a FormControl
        const containedCtrl = inputElement.querySelector('.form-control');
        if (containedCtrl) {
            return containedCtrl;
        }
    }

    // InputElement is a FormControl (or couldn't found FormControl)
    return inputElement;
}

const decrementStep = function(id) {
    const steps = document.getElementById(id);
    const minStep = 0;

    let active = Number(null == steps ? void 0 : steps.getAttribute("active"));
    active = minStep === active ? active : active - 1,
    null == steps || steps.setAttribute("active", active.toString())
}

const incrementStep = function(id) {
    const steps = document.getElementById(id);
    const maxStep = steps.childElementCount - 1;

    let active = Number(null == steps ? void 0 : steps.getAttribute("active"));
    active = maxStep === active ? active : active + 1;
    null == steps || steps.setAttribute("active", active.toString());
}

const changePageForm = (form, idCurrentPage, idTargetPage, validateCurrentFormPage) => {
    const currentPage = form.querySelector('#pagina' + idCurrentPage);

    if (validateCurrentFormPage) {
        const isCurrentFormPageValid = evaluateValidForm(currentPage);
        if (!isCurrentFormPageValid) {
          // Block next form when invalid
          return;
        }
    }

    const targetPage = form.querySelector('#pagina' + idTargetPage);
    currentPage.classList.add("pageHidden");
    targetPage.classList.remove("pageHidden");

    // Actualizar título de formulario
    form.titleText = form.titleText.replace("Paso " + idCurrentPage, "Paso " + idTargetPage);
    form.scrollIntoView({
        behavior: "smooth"
    });
}


const addFileUploaderEvents = (fileUploader) => {
    fileUploader.beforeUpload = (file) => handleBeforeUpload(file, fileUploader.dataset.sizeLimit, fileUploader);
    fileUploader.httpRequest = (options) => null;

    fileUploader.addEventListener('previewEvent', function (e) {
        const file = e.detail.file;
        if (file.alreadyUploaded) {
            const docUrl = file.url;
            window.open(docUrl, '_blank');
        }
    });

    let fileList = fileUploader.fileList;

    fileUploader.addEventListener('exceedEvent', function (e, fileList) {
        let fileLimit = fileUploader.getAttribute("limit");
        fileUploader.setAttribute("error-message", "El número máximo de archivos que se pueden subir es de " + fileLimit);
    });
}

const handleBeforeUpload = (file, megabytesLimit, fileUploader) => {
    file.status = "success";

    // Check fileSize over input limit
    if (file.size > megabytesLimit*1000*1000) {
        showNotification('error', "Ha ocurrido un error al subir el documento.", "El documento " + file.name + " supera el tamaño máximo permitido.");
        return false;
    } else {
        return true;
    }
}


const DocID_Type = Object.freeze({
    NIF: '1',
    NIE: '2',
    CIF: '3'
});

const toggleRepresentadoInputs = (isHidden, tipoDoc) => {
    document.querySelector("[data-type='representadoNombreRS']").hidden = isHidden;
    const isCIF = tipoDoc && tipoDoc.value === DocID_Type.CIF;
    document.querySelector("[data-type='representadoApellido1']").hidden = isHidden || isCIF;
    document.querySelector("[data-type='representadoApellido2']").hidden = isHidden || isCIF;
    document.querySelector("[data-type='representadoCheckPostal']").hidden = isHidden || isCIF;
    document.querySelectorAll("[data-type='representadoEmail']").forEach(input => {
        input.style.display = isHidden ? "none" : "";
    });
    document.querySelector("[data-type='representadoTelefono']").hidden = isHidden;
    document.querySelector("[data-type='certificadoRepresentacion']").hidden = isHidden;
}

const hideRepresentadoApellidos = (event) => {
    const isCIF = event.detail === DocID_Type.CIF;
    // Oculta inputs de apellidos si se selecciona CIF
    document.querySelector("[data-type='representadoApellido1']").hidden = isCIF;
    document.querySelector("[data-type='representadoApellido2']").hidden = isCIF;
}

const comprobarDiferenteRepresentado = () => {
    let isDifRepre = true;
    const tipoDocRepresentado = document.querySelector("[data-type='representadoTipoDoc']");
    let nifRepresentado="";
    switch (tipoDocRepresentado.value) {
        case "1":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoNif']");
            break;
        case "2":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoNie']");
            break;
        case "3":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoCif']");
            break;
        case "4":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoOtros']");
            break;
    }

    const tipoDocRepresentante = document.querySelector("[data-type='tipoDocSolicitante']");
    let nifRepresentante ="";
    switch (tipoDocRepresentante.value) {
        case "1":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteNif']");
            break;
        case "2":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteNie']");
            break;
        case "3":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteCif']");
            break;
        case "4":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteOtros']");
            break;
    }

    if (nifRepresentante.value == nifRepresentado.value) {
        isDifRepre = false;
    }

    return isDifRepre;
}

const handleRepresentaButtonEvent = (idCli, idProc) => {
    // Campos de Representado ocultos por defecto
    toggleRepresentadoInputs(true);

    const btnRepresenta = document.querySelector("#compruebaRepresenta");
    btnRepresenta.addEventListener("click", () => comprobarRepresentacion(idCli, idProc));
}

const comprobarRepresentacion = (idCli, idProc) => {
    const statusRepresenta = document.querySelector("#statusRepresenta");

    const tipoDocRepresentante = document.querySelector("[data-type='tipoDocSolicitante']");
    let nifRepresentante ="";
    switch (tipoDocRepresentante.value) {
        case "1":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteNif']");
            break;
        case "2":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteNie']");
            break;
        case "3":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteCif']");
            break;
        case "4":
            nifRepresentante = document.querySelector("[data-type='idSolicitanteOtros']");
            break;
    }

    const tipoDocRepresentado = document.querySelector("[data-type='representadoTipoDoc']");

    let nifRepresentado="";

    switch (tipoDocRepresentado.value) {
        case "1":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoNif']");
            break;
        case "2":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoNie']");
            break;
        case "3":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoCif']");
            break;
        case "4":
            nifRepresentado = document.querySelector("[data-type='idRepresentadoOtros']");
            break;
    }

    const fileUploader = document.querySelector("[data-type='certificadoRepresentacion']");

    const representanteFilled = evalRequiredControl(nifRepresentante);
    const tipoDocRepresentadoFilled = evalRequiredControl(tipoDocRepresentado);
    const representadoFilled = evalRequiredControl(nifRepresentado) && evalValidControl(nifRepresentado);
    const isRepresentadoDif = comprobarDiferenteRepresentado();
    if (representanteFilled && tipoDocRepresentadoFilled && representadoFilled && isRepresentadoDif) {
        const representaBody = {
            "representanteNif": nifRepresentante.value,
            "representadoNif": nifRepresentado.value,
            "idProcedimiento": idProc,
            "idCliente": idCli
        }

        toggleLoadingSpinner(true, "Estamos comprobando tu representación.", "Espera, por favor.");

        fetch(contextPath + "/.rest/utils/v1/representa", {
            method: 'POST',
            body: JSON.stringify(representaBody),
            headers: {
                "Content-Type": "application/json"
            }
        }).then((response) => {
            toggleLoadingSpinner(false);
            return response.json();
        }).then((res) => {
            console.log(res);
            console.log("Resultado: " + res.resultado + " | HayError: " + res.hayError);

            statusRepresenta.value = "true"; // Se ha pasado por Representa
            const esRepresentante = res.resultado === 'true' || (res.resultado === 'false' ? false : res.resultado)
            if (esRepresentante && !res.hayError) {
                // Representación OK
                showNotification('success', 'Representación válida.');

                fileUploader.required = false;
                toggleRepresentadoInputs(false, tipoDocRepresentado);
            } else {
                // Representación KO
                showNotification('error', 'Los datos de representación no son correctos.', 'Puedes subir un certificado de representación.');

                fileUploader.required = true;
                fileUploader.hidden = false;
                toggleRepresentadoInputs(false, tipoDocRepresentado);
            }
        }).catch((error) => {
            toggleLoadingSpinner(false);

            showNotification('error', 'Se ha producido un error al procesar tu solicitud', 'Vuelve a intentarlo más tarde');
            console.error(error);

            statusRepresenta.value = "true"; // Falla Representa, no bloqueamos avance

            fileUploader.required = true;
            fileUploader.hidden = false;
            toggleRepresentadoInputs(false, tipoDocRepresentado);
        });
    } else {
        if (!isRepresentadoDif) {
            showNotification('error', 'Solicitante y representado deben ser diferentes personas.');
        } else {
            showNotification('error', 'Debes completar correctamente los campos obligatorios');
        }
    }
}


const handleRespuestasFormularios = async (camposList, idCli, userId, isAutofirma) => {
    let responseList = [];

    for (const campo of camposList) {
        let campoData = campo.extra;
        console.log(campoData);

        if (campoData) {
            switch (campoData.idTipoCampo) {
                case 6: // Checkbox Group
                    let ordenarValues = campo.value.sort(function (a, b) {
                        return a - b;
                      });
                    campoData.respuesta = ordenarValues.join("; ");
                    break;
                case 8: // Files
                    let fileList = campo.fileList;
                    if (isAutofirma && fileList.length > 0) {
                        // Lanzamos Firma de documentos con AutoFirma.
                        try {
                            toggleLoadingSpinner(true, "Abriendo aplicación de AutoFirma...", "Por favor, completa el proceso de firma para continuar");
                            const fileListRaw = fileList.map(file => file.raw);
                            const signResults = await doMultiSignAsPromise(fileListRaw, userId);

                            for (let i = 0; i < signResults.length; i++) {
                                // Replace original files with signed ones
                                fileList[i].raw = await base64ToFile(
                                    signResults[i].signatureB64,
                                    fileList[i].name,
                                    fileList[i].type
                                );
                            }
                        } catch (error) {
                            toggleLoadingSpinner(false);

                            showNotification('error', 'Se ha producido un error al realizar la firma', error.errorMessage ?? '');

                            throw new Error(error);
                        }
                    }

                    try {
                        // Upload file list
                        const tipoEstructural = campoData.tipoEstructural;
                        const idDocumentsList = await uploadFiles(fileList, tipoEstructural, idCli);
                        campoData.respuesta = idDocumentsList.join("; ");
                    } catch (error) {
                        // Error on Upload File. Abort parent process
                        throw new Error(error);
                    }
                    break;
                case 13: // Decimal
                    campoData.respuesta = isEmpty(campo.value) ? "" : campo.value.replace(',', '.');
                    break;
                case 18: // Fecha
                case 19: //Fecha y hora
                    campoData.respuesta = isEmpty(campo.value) ? "" : campo.value;
                    break;
                case 22: // Opción Pago
                    if(campo.value != "") {
                        campoData.respuesta = Number(campo.value);
                    }
                    break;
                default:
                    campoData.respuesta = campo.value;
                    break;
            }

            responseList.push(campoData);
        } else {
            console.error(campo.label + " no extra " + campo.id);
        }
    };

    console.warn(responseList);
    return responseList;
}

const sendGuardarBorrador = async (id, idCli, idProc, idAmb, idForm, idFormPa, nifSol, incompleto) => {
    let borradorData = {
        "id": id,
        "idCliente": idCli,
        "idProcedimiento": idProc,
        "idFormularioPadre": idFormPa,
        "idFormulario": idForm,
        "idAmbito": idAmb,
        "estado": "",
        "solicitanteNif": nifSol,
        "fechaFaseInicio": ""
    }
    console.warn(borradorData);


    const elementsSelectors = [
        "div.formContainer:not([hidden]) .form-control:not([hidden])",
        "div.formContainer .form-control.form-data",
        "div.formContainer.formData .form-control"
    ]
    const controls = document.querySelectorAll(elementsSelectors.join(", "));
    let responseList = [];
    try {
        responseList = await handleRespuestasFormularios(controls, idCli, nifSol, false);
    } catch (error) {
        // Abort GuardarBorrador
        return;
    }

    const postBody = new URLSearchParams();
    postBody.append("borrador", JSON.stringify(borradorData));
    postBody.append("respuestas", JSON.stringify(responseList));
    postBody.append("incompleto", incompleto);

    toggleLoadingSpinner(true, "Estamos procesando tu solicitud...", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    try {
        console.time("Guardando borrador...");
        const response = await fetch(contextPath + "/.rest/formulario/v1/borrador", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            body: postBody
        });

        if (!response.ok) throw new Error(`Initial API error: ${response.status}`);

        const data = await response.json();
        const instancia = data.instancia;

        if (!instancia) throw new Error('No instancia returned from API');

        // Start polling loop to status
        const res = await pollStatus("borrador", instancia, 30 * 1000, 5 * 60 * 1000);

        if (!res.hayError && res.idBorrador) {
            if (incompleto) {
                toggleLoadingSpinner(true, "Volviendo a listado de expedientes...", "Espera, por favor.");
                // Borrador incompleto. Redirección a expedientes.
                window.location.href = linkPrefix + "/privada/expedientes?subtipo=1";
            } else {
                toggleLoadingSpinner(true, "Preparando proceso de firma...", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");
                // Borrador completo. Redirección a firma.
                window.location.href = linkPrefix + "/procedimiento/firma?idProc=" + idProc + "&idBorr=" + res.idBorrador + "&idAmb=" + idAmb;
            }
        } else {
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')' , '');
        }
        console.timeEnd("Guardando borrador...");
    } catch (error) {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu solicitud', 'Vuelve a intentarlo más tarde');
        console.error(error);
        console.timeEnd("Guardando borrador...");
    }
};


const createExpediente = async (idBorrador, idCli, nifSol, isClave) => {
    const borradorData = document.querySelector('#borr_borrador').value;
    const respuestasData = document.querySelector('#borr_respuestas').value;

    // Check selected tipoFirma
    const tipoFirma = document.querySelector("#exp_firmaTipo").value;
    let isAutofirma = tipoFirma === 'autofirma';

    const urlParams = new URLSearchParams(window.location.search);
    const hasSignValidation = urlParams.get('signValidation');
    if (!isAutofirma && isClave && !hasSignValidation) {
        // Revalidacion con Clave Auth
        window.location.href = CLAVE_VALIDATE_URL + encodeURIComponent(window.location.href);
        return;
    }

    const postBody = new URLSearchParams();
    postBody.append("expediente", borradorData);
    postBody.append("respuestas", respuestasData);
    postBody.append("idBorrador", idBorrador);
    postBody.append("autofirma", isAutofirma);

    const loadingTitle = tipoFirma === 'autofirma' ? "Generando documento de solicitud para firmar..." : "Estamos procesando tu solicitud...";
    toggleLoadingSpinner(true, loadingTitle, "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    try {
        console.time("Creando expediente del borrador: " + idBorrador);
        const response = await fetch(contextPath + "/.rest/formulario/v1/expediente", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            body: postBody
        });

        if (!response.ok) throw new Error(`Initial API error: ${response.status}`);

        const data = await response.json();
        const instancia = data.instancia;

        if (!instancia) throw new Error('No instancia returned from API');

        // Start polling loop to status
        const res = await pollStatus("expediente", instancia, 60 * 1000, 5 * 60 * 1000);

        if (res.idExpediente && !res.hayError) {
            if (isAutofirma) {
                startAutofirma(res.idExpediente, idCli, res.idDocumentoSolicitud, nifSol);
            } else {
                window.location.replace(linkPrefix + "/procedimiento/confirmacionSolicitud?idExp=" + res.idExpediente);
            }
        } else {
            toggleLoadingSpinner(false);

            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            if (res.codigoError) {
                showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
            } else {
                showNotification('info', mensajeError, '');
            }
        }
        console.timeEnd("Creando expediente del borrador: " + idBorrador);
    } catch (error) {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu solicitud', 'Vuelve a intentarlo más tarde');
        console.error(error);
        console.timeEnd("Creando expediente del borrador: " + idBorrador);
    }
};


const startAutofirma = async (idExpediente, idCli, idDocumento, nifSol) => {

    let file = await downloadDocument(idDocumento, "docExpediente");

    // Lanzamos Firma del documento con AutoFirma.
    try {
        toggleLoadingSpinner(true, "Abriendo aplicación de AutoFirma...", "Por favor, completa el proceso de firma para continuar");

        const signResponse = await doSignAsPromise(file, nifSol);

        file = await base64ToFile(signResponse.signatureB64, file.name, file.type);

        sendFirmaExpediente(idExpediente, idCli, file);
    } catch (error) {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al realizar la firma', error.errorMessage ?? '');
        return;
    }
}

const sendFirmaExpediente = async (idExpediente, idCli, signedFile) => {
    toggleLoadingSpinner(true, "Estamos procesando tu solicitud...", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    const formData = new FormData();
    formData.append('file', signedFile);

    try {
        console.time("Firmando Autofirma del expediente: " + idExpediente);
        const response = await fetch(contextPath + "/.rest/formulario/v1/autofirma?" + new URLSearchParams({
                idCliente: idCli,
                idExpediente: idExpediente,
            }), {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error(`Initial API error: ${response.status}`);

        const data = await response.json();
        const instancia = data.instancia;

        if (!instancia) throw new Error('No instancia returned from API');

        // Start polling loop to status
        const res = await pollStatus("autofirma", instancia, 30 * 1000, 5 * 60 * 1000);

        if (!res.hayError && res.idExpediente) {
            window.location.replace(linkPrefix + "/procedimiento/confirmacionSolicitud?idExp=" + res.idExpediente);
        } else {
            toggleLoadingSpinner(false);

            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        }
        console.timeEnd("Firmando Autofirma del expediente: " + idExpediente);
    } catch (error) {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu solicitud', 'Vuelve a intentarlo más tarde');
        console.log(error);
        console.timeEnd("Firmando Autofirma del expediente: " + idExpediente);
    }
}

const MODAL_ACTUACION_FUNCIONARIO = "modalActuacionFuncionario";
const openModalActuacionFuncionario = () => {
    toggleModal(MODAL_ACTUACION_FUNCIONARIO, true);
}

const seleccionaModoActuacion = (idFormHabilita) => {
    const modalActuacion = document.querySelector('#' + MODAL_ACTUACION_FUNCIONARIO);
    const modoActuacion = modalActuacion.querySelector('#modoActuacion').value;

    if (modoActuacion === 'solicitante') {
        // Move user data to Solicitante inputs
        const seccionesDatos = document.querySelectorAll(".seccionSolicitante");
        const datosFuncionario = seccionesDatos[0];
        const nifFuncionario = datosFuncionario.querySelector("[id$='f" + idFormHabilita + "c1_4']")?.value;
        const nombreFuncionario = datosFuncionario.querySelector("[id$='f" + idFormHabilita + "c1_1']")?.value;
        const primerApeFuncionario = datosFuncionario.querySelector("[id$='f" + idFormHabilita + "c1_2']")?.value;
        const segundoApeFuncionario = datosFuncionario.querySelector("[id$='f" + idFormHabilita + "c1_3']")?.value;

        const datosSolicitante = seccionesDatos[1];
        const tipoDocSolicitante = datosSolicitante.querySelector("[id$='c3_4']");
        tipoDocSolicitante.value = "1";
        const nifSolicitante = datosSolicitante.querySelector("[id$='c39_30']");
        nifSolicitante.value = nifFuncionario;
        nifSolicitante.hidden = false;
        const nombreSolicitante = datosSolicitante.querySelector("[id$='c1_1']");
        nombreSolicitante.value = nombreFuncionario;
        const primerApeSolicitante = datosSolicitante.querySelector("[id$='c1_2']");
        primerApeSolicitante.value = primerApeFuncionario;
        const segundoApeSolicitante = datosSolicitante.querySelector("[id$='c1_3']");
        segundoApeSolicitante.value = segundoApeFuncionario;

        datosSolicitante.querySelectorAll('.form-control').forEach(control => {
            control.readonly = true;
        });

        // Removes sections of funcionario
        const formFuncionario = document.querySelector("#formFuncionario");
        formFuncionario.remove();
    } else {
        //Como Funcionario Habilitado, si no actúa en nombre propio , eliminamos botón de Guardar Borrador
        const botonesBorrador = document.querySelectorAll(".draft");
        botonesBorrador.forEach(boton => {
            boton.remove();
        });
        toggleModal(MODAL_ACTUACION_FUNCIONARIO, false);
    }
}

const validateID = (id, isNifSolicitante) => {

    let isCorrect = false;

    let regexNif = /^[0-9]{8}[a-zA-Z]$/;
    let regexNie = /^[x-zX-Z][0-9]{7}[a-zA-Z]$/;
    let regexCif = /^[a-wA-W][0-9]{7}[a-jA-J0-9]$/;

    if(regexNif.test(id)) {
        isCorrect = validateNIF(id);
        return isCorrect;
    } else if(regexNie.test(id)) {
        isCorrect = validateNIE(id);
        return isCorrect;
    } else if (regexCif.test(id)) {
        isCorrect = validateCIF(id);
        return isCorrect;
    } else if (isNifSolicitante) {
        return true;
    } else {
console.log ("El documento no es valido.");
        return false;
    }

}

const validateLetra = (numNIF) => {
    let letra = ["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"];
    let resto = (numNIF % 23);

    let letraCalculada = letra[resto];
    return letraCalculada;
};


const validateNIF = (nif) => {

    const numeroDNI = parseInt(nif.slice(0, 8), 10);
    const letraDNI = nif.charAt(8).toUpperCase();

    const letraCalculada = validateLetra(numeroDNI);

    return letraDNI === letraCalculada;
;}

const validateNIE = (nie) => {

    let numeroNIE = nie.slice(1, 8);

    const letraInicial = nie.charAt(0).toUpperCase();
        switch (letraInicial) {
            case "X":
                numeroNIE = "0" + numeroNIE;
                break;
            case 'Y':
                numeroNIE = '1' + numeroNIE;
                break;
            case 'Z':
                numeroNIE = '2' + numeroNIE;
                break;
    }

    const letraNIE = nie.charAt(8).toUpperCase();

    const letraCalculada = validateLetra(parseInt(numeroNIE, 10));

    return letraNIE === letraCalculada;
;}

const validateCIF = (cif) => {

    let letraInicial = cif.charAt(0).toUpperCase();
    let numeroCIF = cif.slice(1, 8);
    let digitoControl = cif.charAt(8).toUpperCase();

    let sumaPar = 0;
    let sumaImpar = 0;

    for (let i = 0; i < 7; i++) {
        const numero = parseInt(numeroCIF.charAt(i),10);
        if (i % 2 === 0) {
            let producto = numero * 2;
            sumaImpar += Math.floor(producto / 10) + (producto % 10);
        } else {
            sumaPar += numero;
        }
    }

    let sumaResultados = sumaImpar + sumaPar

    let resto = (sumaResultados % 10);
    let cifCalculado = 10 - resto ;

    if(cifCalculado === 10) {
        cifCalculado = 0;
    }

    const regexCalc = /^[0-9]$/;
    let letraCalculada = "";

    if ("ABEH".includes(letraInicial)) {
        letraCalculada = cifCalculado;
    } else if ("KPQS".includes(letraInicial)) {
        let letra = ["J","A","B","C","D","E","F","G","H","I"];

        letraCalculada = letra[cifCalculado];
    } else {

        if (regexCalc.test(digitoControl)) {
            letraCalculada = cifCalculado;
        } else {
            let letra = ["J","A","B","C","D","E","F","G","H","I"];

            letraCalculada = letra[cifCalculado];
        }
    }

    return digitoControl == letraCalculada;
;}

const handleRecuperarConsentimiento = (nifFuncionario, idProcedimiento) => {
    const recupConse = document.getElementById('recuperarConsentimiento');
    const nifSol = document.querySelector("[data-type='idSolicitanteNif']");
    const nieSol = document.querySelector("[data-type='idSolicitanteNie']");
    //const cifSol = document.querySelector("[data-type='idSolicitanteCif']");
    const otrosSol = document.querySelector("[data-type='idSolicitanteOtros']");
    var nifSolInput;
    nifSol.addEventListener("changeEvent", function(event) {
        recupConse.isDisabled = isEmpty(nifSol.value);
        nifSolInput= nifSol.value;
    });

    nieSol.addEventListener("changeEvent", function(event) {
        recupConse.isDisabled = isEmpty(nieSol.value);
        nifSolInput= nieSol.value;
    });

    /*cifSol.addEventListener("changeEvent", function(event) {
        // Enable button when 'nifSolicitante' is completed
        recupConse.isDisabled = isEmpty(cifSol.value);
        nifSolInput= cifSol.value;
    });*/

    otrosSol.addEventListener("changeEvent", function(event) {
        recupConse.isDisabled = isEmpty(otrosSol.value);
        nifSolInput= otrosSol.value;
    });

    recupConse.addEventListener("click", function(event) {
      getConsentFile(nifFuncionario, nifSolInput, idProcedimiento);
    });
}

const getConsentFile = (nifFuncionario, nifCiudadano, idProcedimiento) => {
    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Espera, por favor.");

    const consentBody = {
        nifFuncionario: nifFuncionario,
        nifCiudadano: nifCiudadano,
        idProcedimiento: idProcedimiento
    };

    fetch(contextPath + "/.rest/utils/v1/consentimiento", {
        method: 'POST',
        body: JSON.stringify(consentBody),
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {
        console.log(response);
        return response.json();
    }).then((res) => {
        if (res.resultado !== null) {
            toggleLoadingSpinner(false);
            showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        } else {
            console.log("Error al procesar...");
            toggleLoadingSpinner(false);
            // Mostrar Toast
            showNotification('error', 'Se ha producido un error al procesar tu petición', res.mensajeError);
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
}

const handleValidarRoacEvent = (formId, required, webAPIParams) => {
    if (!required) {
        // Si el Comp. ROAC es opcional, se obliga a Validar si el campo NumROAC se completa
        const numROAC = document.querySelector("[data-type='roac']");
        const statusROAC = document.querySelector("#statusROAC");
        
        numROAC.addEventListener("changeEvent", (event) => {
            statusROAC.required = !isEmpty(numROAC.value);
        });
    }

    const btnValidarRoac = document.querySelector("#validarRoac");
    btnValidarRoac.addEventListener("click", () => validarRoac(formId, webAPIParams));
}

const validarRoac = (formId, webAPIParams) => {

    webAPIParams = fillValuesFromFormInputs(webAPIParams, formId);

    // Check required controls are valid
    let requiredControlsValid = true;
    webAPIParams.forEach(param => {
        requiredControlsValid = evalValidControl(param.campo) && requiredControlsValid;
    });

    if (requiredControlsValid) {
        const statusROAC = document.querySelector("#statusROAC");

        const roacBody = transformWebAPIParams(webAPIParams);

        toggleLoadingSpinner(true, "Estamos validando tu número de Roac.", "Espera, por favor.");

        fetch(contextPath + "/.rest/utils/v1/validarRoac", {
            method: 'POST',
            body: JSON.stringify(roacBody),
            headers: {
                "Content-Type": "application/json"
            }
        }).then((response) => {
            toggleLoadingSpinner(false);
            return response.json();
        }).then((res) => {
            if (!res.hayError) {
                if (res.resultado) {
                    statusROAC.value = "true"; // Se ha pasado por ROAC y resultado OK
                    showNotification('success', 'Validación ROAC válida');
                } else {
                    statusROAC.value = "false"; // Se ha pasado por ROAC y resultado KO
                    showNotification('error', 'El Código ROAC introducido es incorrecto');
                }
            } else {
                showNotification('error', 'Se ha producido un error al procesar tu solicitud', res.mensajeError);
            }
        }).catch((error) => {
            toggleLoadingSpinner(false);

            showNotification('error', 'Se ha producido un error al procesar tu solicitud', 'Vuelve a intentarlo más tarde');
            console.log(error);
        });
    }
}

const fillValuesFromFormInputs = (webAPIParams, formId) => {
    webAPIParams.forEach((param, index) => {
        let campoId, formularioId;

        // Si es el parámetro "dni", buscar el primer campo con valor
        if (param.nombreParametro === "dni") {
            let i = 0;
            let valorEncontrado = false;

            do {
                const key = i === 0 ? "campoRefValor" : `campoRefValor${i + 1}`;
                const fullCampo = param[key];
                if (!fullCampo) break;

                const [formularioIdTmp, campoIdTmp] = fullCampo.split("-");
                const input = document.getElementById("f" + formularioIdTmp + "c" + campoIdTmp);

                if (input && !isEmpty(input.value)) {
                    formularioId = formularioIdTmp;
                    campoId = campoIdTmp;
                    webAPIParams[index].campo = input;
                    webAPIParams[index].campoValue = input.value;
                    valorEncontrado = true;
                }

                i++;
            } while (!valorEncontrado);
        } else {
            // Manejo normal si no es "dni"
            if (param?.campoRefValor.includes("-")) {
                const [formularioIdTmp, campoIdTmp] = param.campoRefValor.split("-");
                formularioId = formularioIdTmp;
                campoId = campoIdTmp;
            } else {
                formularioId = formId;
                campoId = param.campoRefValor;
            }

            const input = document.getElementById("f" + formularioId + "c" + campoId);
            webAPIParams[index].campo = input;
            webAPIParams[index].campoValue = input.value;
        }
    });

    return webAPIParams;
};

const transformWebAPIParams = (webAPIParams) => {
    return webAPIParams.reduce((acc, { nombreParametro, campoValue }) => {
        acc[nombreParametro] = campoValue;
        return acc;
    }, {});
}

async function validarMUFACE(idCli, idProc, numDoc) {
    const consentBody = {
        idCliente: idCli,
        idProcedimiento: idProc,
        numeroDoc: numDoc
    };
    const response = await fetch(contextPath + "/.rest/utils/v1/validarMuface", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        },
        body: JSON.stringify(consentBody)
    });
    const data = await response.json();
    return data;
}

const showMufaceErrorMessage = (errorMessage,description,imageSrc) => {

    // Se eliminan las secciones que va a sustituir el mensaje de error
    const dntheroBlock = document.querySelector("dnt-hero");
    const formDatosBlock = document.querySelector("#form-datos");
    const formSolicitudBlock = document.querySelector("#form-solicitud");
    const formPagoBlock = document.querySelector("#form-pago");
    const formStepsBlock = document.querySelector("#steps-section");

    // Se añade el bloque de error al DOM
    const errorBlock = document.createElement("dnt-section");
    errorBlock.setAttribute("type", "default");
    errorBlock.setAttribute("image-object-fit", "contain");
    errorBlock.setAttribute("h-size", "1");
    errorBlock.setAttribute("title-text", errorMessage);
    errorBlock.setAttribute("description", description);
    const oImage = document.createElement("img");
    oImage.setAttribute("slot", "image");
    oImage.setAttribute("src", imageSrc);
    oImage.setAttribute("alt", "Imagen de error");
    errorBlock.appendChild(oImage);
    errorBlock.setAttribute("id", "errorBlock");

    let oParent = dntheroBlock.parentNode;
    oParent.insertBefore(errorBlock, dntheroBlock);
    // Se eliminan las secciones que ya no son necesarias
    if(dntheroBlock!== null){oParent.removeChild(dntheroBlock);}    
    if(formDatosBlock!==null){oParent.removeChild(formDatosBlock);}
    if(formSolicitudBlock!==null){oParent.removeChild(formSolicitudBlock);}
    if(formPagoBlock!==null){oParent.removeChild(formPagoBlock);}
    if(formStepsBlock!==null){oParent.removeChild(formStepsBlock);}
}

function getDatoscontacto(idCiudadano){
    // Chequamos si está seleccionado como solicitante o como representado.        
    // Selecciona el grupo de botones de radio
    const radioGroup = document.querySelector("[id$='c5_1']");
    const oContacto = {};


    // Por defecto, asumimos que es Solicitante
    const tipoDocSolicitante = document.querySelector("[data-type='tipoDocSolicitante']");
    const tipoDocRepresentado = document.querySelector("[data-type='representadoTipoDoc']");
    oContacto.numeroDoc = idCiudadano;
    try {
        if(radioGroup !== null) {
            // Selecciona los botones de radio dentro del grupo
            const radios = radioGroup.querySelectorAll('dnt-radio');

            // Itera sobre los botones de radio para encontrar el seleccionado
            let selectedValue = "1";
            radios.forEach(radio => {
                // Comprueba si el botón de radio está seleccionado
                if (radio.getAttribute('checked') === 'true' || radio.shadowRoot.querySelector('.dnt-radio.is-checked') != null) {
                    selectedValue = radio.getAttribute('true-label');
                }
            });

            // Si es Representado
            if (selectedValue === "2") {
                switch (tipoDocRepresentado.value) {
                    case "1":
                        oContacto.numeroDoc = document.querySelector("[data-type='idRepresentadoNif']").value;
                        break;
                    case "2":
                        oContacto.numeroDoc = document.querySelector("[data-type='idRepresentadoNie']").value;
                        break;
                    case "3":
                        oContacto.numeroDoc = document.querySelector("[data-type='idRepresentadoCif']").value;    
                        break;
                    case "4":
                        oContacto.numeroDoc = document.querySelector("[data-type='idRepresentadoOtros']").value;    
                        break;
                    }        
            }
        }
    }
    catch(error){
        //console.error("Error obteniendo datos de contacto: " + error);
        oContacto.numeroDoc = idCiudadano;
    }   

    return oContacto;
}

const validateIBAN = (iban) => {
    // Limpiar el IBAN: quitar espacios y convertir a mayúsculas
    iban = iban.toUpperCase().replace(/\s/g, '');

    // Dividir el número en diferentes partes
    let ibanReorganizado = iban.slice(4) + iban.slice(0, 4);

    // Convertir letras a números
    let ibanNumerico = '';
    for (let char of ibanReorganizado) {
        if (char >= '0' && char <= '9') {
            ibanNumerico += char;
        } else {
            ibanNumerico += (char.charCodeAt(0) - 55).toString();
        }
    }

    // Convertir a entero y calcular el módulo 97
    let ibanEntero = BigInt(ibanNumerico);
    return ibanEntero % 97n === 1n;
}

const descargarBorrador = (idBorrador) => {
    if (!isEmpty(idBorrador)) {
        toggleLoadingSpinner(true, "Estamos generando el borrador de tu solicitud...", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

        fetch(contextPath + "/.rest/formulario/v1/documentoBorrador?" + new URLSearchParams({
                idBorrador: idBorrador
            }), {
            method: 'GET'
        }).then((response) => {
            toggleLoadingSpinner(false);
            return response.blob();
        }).then((blob) => {
            const fileUrl = URL.createObjectURL(blob);
            window.open(fileUrl, '_blank');

            // Revoke URL after 10 seconds
            setTimeout(() => {
                URL.revokeObjectURL(fileUrl);
            }, 10000);
        }).catch((error) => {
            toggleLoadingSpinner(false);

            showNotification('error', 'Se ha producido un error al procesar tu solicitud', 'Vuelve a intentarlo más tarde');
            console.log(error);
        });
    }
}