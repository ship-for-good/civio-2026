const MODAL_ALEGACION = "modalAlegacion";
const MODAL_APORTARDOCUMENTACION = "modalAportarDocumentacion";
const MODAL_REQUERIMIENTO = "modalRequerimiento";
const MODAL_PRUEBA = "modalPrueba";
const MODAL_COMPARECENCIA = "modalComparecencia";
const MODAL_REQUERIMIENTOPAGO = "modalRequerimientoPago";
const MODAL_RESPUESTACONTROLGESTION = "modalRespuestaControlGestion";
const MODAL_DOCUMENTOS = "modalDocumentos";


const IDS_CAMPOS_REQUERIMIENTO = Object.freeze({
    RESPUESTA: '2_1',
    DOCU_ADJUNTOS: '8_3'
})

const IDS_CAMPOS_PRUEBAS = Object.freeze({
    COMENTARIO: '2_1',
    ARCHIVO: '8_2'
})

const IDS_CAMPOS_ALEGACION = Object.freeze({
    TIPO_ALEGACION: '3_1',
    SOLICITA: '2_2',
    ALEGA: '2_3',
    DOCU_ADJUNTOS: '8_4'
})

const IDS_CAMPOS_APORTARDOCUMENTACION = Object.freeze({
    MOTIVO: '2_3',
    DOCU_ADJUNTOS: '8_2'
})

const IDS_CAMPOS_CONTROLGESTION = Object.freeze({
    MOTIVO: '2_3',
    DOCU_ADJUNTOS: '8_2'
})

// MODAL ALEGACION
const loadModalAlegacion = () => {
    const modal = document.querySelector('#' + MODAL_ALEGACION);

    const nombreProcedimiento = document.querySelector("#nombreProcedimiento").value;
    modal.querySelector("#aleg_nomProc").value = nombreProcedimiento;

    toggleModal(MODAL_ALEGACION, true);
}

const evalAndSendAlegacion = (isClave, idCliente, nifSol) => {
    const modal = document.querySelector('#' + MODAL_ALEGACION);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendAlegacionRequest(isClave, idCliente, nifSol);
}

const sendAlegacionRequest = async (isClave, idCliente, nifSol, isCallbackFromClave) => {
    const urlSearch = window.location.search;
    const urlParams = new URLSearchParams(urlSearch);
    const idExp = urlParams.get('id');

    const modal = document.querySelector('#' + MODAL_ALEGACION);
    const tipoFirma = modal.querySelector("#aleg_firmaTipo").value;
    let isAutofirma = tipoFirma === 'autofirma';

    let responseList = [];
    if (!isCallbackFromClave) {
        // Obtener respuestas de los campos de la modal de Aportar Documentación
        const elementsSelectors = [
            "div.formContainer.formTramite:not([hidden]) .form-control:not([hidden])",
            "div.formContainer.formTramite .form-control.form-data"
        ]
        const controls = modal.querySelectorAll(elementsSelectors.join(", "));
        try {
            responseList = await handleRespuestasFormularios(controls, idCliente, nifSol, isAutofirma);
        } catch (error) {
            // Abort SendRequest
            return;
        }
    }

    // Revalidacion con Clave Auth (si es usuario Clave y no ha seleccionado Autofirma)
    if (!isAutofirma && isClave) {
        if (isCallbackFromClave) {
            // Recover session data (Callback from Clave)
            const sessionAlega = sessionStorage.getItem("alegaPending");
            const alegaRequest = JSON.parse(sessionAlega);
            responseList = alegaRequest.respuestas;

            // Remove pending data
            sessionStorage.removeItem("alegaPending");
            urlParams.delete('signValidation');
            urlParams.delete('signType');
        } else {
            // Save data to session (Redirect to Clave)
            const requestData = {
                "respuestas": responseList
            }
            sessionStorage.setItem("alegaPending", JSON.stringify(requestData));

            window.location.href = CLAVE_VALIDATE_URL + encodeURIComponent(window.location.href + "&signType=alegacion");
            return;
        }
    }

    const postBody = new URLSearchParams();
    postBody.append("idExpediente", idExp);
    postBody.append("solicitanteNif", nifSol);
    postBody.append("respuestas", JSON.stringify(responseList));
    postBody.append("autofirma", isAutofirma);

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/alegacion/v1/respuesta", {
        method: 'POST',
        body: postBody
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);
        if (res.hayError || res.error) {
            console.log("Error al procesar Alegación");
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            toggleModal(MODAL_ALEGACION, false);

            window.location.search = urlParams.toString() + "&msg=1001";
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
};

// MODAL APORTAR DOCUMENTACION
const loadModalAportarDocumentacion = () => {
    const modal = document.querySelector('#' + MODAL_APORTARDOCUMENTACION);

    const nombreProcedimiento = document.querySelector("#nombreProcedimiento").value;
    modal.querySelector("#aporDocu_nomProc").value = nombreProcedimiento;

    toggleModal(MODAL_APORTARDOCUMENTACION, true);
}

const evalAndSendAportarDocumentacion = (isClave, idCliente, nifSol) => {
    const modal = document.querySelector('#' + MODAL_APORTARDOCUMENTACION);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendAportarDocuRequest(isClave, idCliente, nifSol);
}

const sendAportarDocuRequest = async (isClave, idCliente, nifSol, isCallbackFromClave) => {
    const urlSearch = window.location.search;
    const urlParams = new URLSearchParams(urlSearch);
    const idExp = urlParams.get('id');

    const modal = document.querySelector('#' + MODAL_APORTARDOCUMENTACION);
    const tipoFirma = modal.querySelector("#aporDocu_firmaTipo").value;
    let isAutofirma = tipoFirma === 'autofirma';

    let responseList = [];
    if (!isCallbackFromClave) {
        // Obtener respuestas de los campos de la modal de Aportar Documentación
        const elementsSelectors = [
            "div.formContainer.formTramite:not([hidden]) .form-control:not([hidden])",
            "div.formContainer.formTramite .form-control.form-data"
        ]
        const controls = modal.querySelectorAll(elementsSelectors.join(", "));
        try {
            responseList = await handleRespuestasFormularios(controls, idCliente, nifSol, isAutofirma);
        } catch (error) {
            // Abort SendRequest
            return;
        }
    }

    // Revalidacion con Clave Auth (si es usuario Clave y no ha seleccionado Autofirma)
    if (!isAutofirma && isClave) {
        if (isCallbackFromClave) {
            // Recover session data (Callback from Clave)
            const sessionAportarDoc = sessionStorage.getItem("aportarDocPending");
            const aportarDocRequest = JSON.parse(sessionAportarDoc);
            responseList = aportarDocRequest.respuestas;

            // Remove pending data
            sessionStorage.removeItem("aportarDocPending");
            urlParams.delete('signValidation');
            urlParams.delete('signType');
        } else {
            // Save data to session (Redirect to Clave)
            const requestData = {
                "respuestas": responseList
            }
            sessionStorage.setItem("aportarDocPending", JSON.stringify(requestData));

            window.location.href = CLAVE_VALIDATE_URL + encodeURIComponent(window.location.href + "&signType=aportarDocumentacion");
            return;
        }
    }


    const postBody = new URLSearchParams();
    postBody.append("idExpediente", idExp);
    postBody.append("ciudadano", nifSol);
    postBody.append("respuestas", JSON.stringify(responseList));
    postBody.append("autofirma", isAutofirma);

    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/seguimiento/v1/respuesta", {
        method: 'POST',
        body: postBody
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        if (res.hayError || res.error) {
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', '' + mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            toggleModal(MODAL_APORTARDOCUMENTACION, false);
            window.location.search = urlParams.toString() + "&msg=1001";
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
};



// MODAL REQUERIMIENTO
const loadModalRequerimiento = (idRequerimiento) => {
    const modalReque = document.querySelector('#' + MODAL_REQUERIMIENTO);

    const nombreProcedimiento = document.querySelector("#nombreProcedimiento").value;
    modalReque.querySelector("#reque_nomProc").value = nombreProcedimiento;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Cargando detalle del trámite...", "Espera, por favor.");

    fetch(contextPath + "/.rest/requerimiento/v1/detalle?" + new URLSearchParams({
            idRequerimiento: idRequerimiento,
        }), {
        method: 'GET'
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);

        const validResponse = !isEmpty(res) && !isEmpty(res.data) && !isEmpty(res.data.requerimiento);
        if (validResponse) {
            const requerimientoData = res.data.requerimiento[0];

            modalReque.setAttribute('title-text', "Responder al requerimiento " + requerimientoData.codigo);
            modalReque.dialogLabel = "Responder al requerimiento " + requerimientoData.codigo;
            modalReque.querySelector("#reque_codigo").value = requerimientoData.codigo;
            modalReque.querySelector("#reque_id").value = requerimientoData.id;

            modalReque.querySelector("#reque_motivo").value = requerimientoData.motivo;
            modalReque.querySelector("#reque_plazo").value = requerimientoData.diasSuspension + " días";
            const fechaIni = new Date(requerimientoData.fechaInicio);
            modalReque.querySelector("#reque_fechaIni").value = DATE_FORMATTER.format(fechaIni);
            if (requerimientoData.fechaFinalizacion) {
                const fechaCad = new Date(requerimientoData.fechaFinalizacion);
                modalReque.querySelector("#reque_fechaCad").value = DATE_FORMATTER.format(fechaCad);
            } else {
                modalReque.querySelector("#reque_fechaCad").hidden = true;
            }

            toggleModal(MODAL_REQUERIMIENTO, true);
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        console.error(error)
    });
}

const evalAndSendRequerimiento = (isClave, idCliente, nifSol) => {
    const modal = document.querySelector('#' + MODAL_REQUERIMIENTO);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendRequerimientoResponse(isClave, idCliente, nifSol);
}

const sendRequerimientoResponse = async (isClave, idCliente, nifSol, isCallbackFromClave) => {
    const urlSearch = window.location.search;
    const urlParams = new URLSearchParams(urlSearch);
    const idExp = urlParams.get('id');

    const modal = document.querySelector('#' + MODAL_REQUERIMIENTO);
    let idRequerimiento = modal.querySelector("#reque_id").value;
    let codigo = modal.querySelector("#reque_codigo").value;
    const tipoFirma = modal.querySelector("#reque_firmaTipo").value;
    let isAutofirma = tipoFirma === 'autofirma';

    let responseList = [];
    if (!isCallbackFromClave) {
        // Obtener respuestas de los campos del modal de Requerimiento
        const elementsSelectors = [
            "div.formContainer.formTramite:not([hidden]) .form-control:not([hidden])",
            "div.formContainer.formTramite .form-control.form-data"
        ]
        const controls = modal.querySelectorAll(elementsSelectors.join(", "));
        try {
            responseList = await handleRespuestasFormularios(controls, idCliente, nifSol, isAutofirma);
        } catch (error) {
            // Abort SendRequest
            return;
        }
    }

    // Revalidacion con Clave Auth (si es usuario Clave y no ha seleccionado Autofirma)
    if (!isAutofirma && isClave) {
        if (isCallbackFromClave) {
            // Recover session data (Callback from Clave)
            const sessionRequerimiento = sessionStorage.getItem("requerimientoPending");
            const controlRequeRequest = JSON.parse(sessionRequerimiento);
            idRequerimiento = controlRequeRequest.idRequerimiento;
            codigo = controlRequeRequest.codigo
            responseList = controlRequeRequest.respuestas;

            // Remove pending data
            sessionStorage.removeItem("requerimientoPending");
            urlParams.delete('signValidation');
            urlParams.delete('signType');
        } else {
            // Save data to session (Redirect to Clave)
            const requestData = {
                "codigo": codigo,
                "idRequerimiento": idRequerimiento,
                "respuestas": responseList
            }
            sessionStorage.setItem("requerimientoPending", JSON.stringify(requestData));

            window.location.href = CLAVE_VALIDATE_URL + encodeURIComponent(window.location.href + "&signType=requerimiento");
            return;
        }
    }

    const postBody = new URLSearchParams();
    postBody.append("idExpediente", idExp);
    postBody.append("idRequerimiento", idRequerimiento);
    postBody.append("codigo", codigo);
    postBody.append("respuestas", JSON.stringify(responseList));
    postBody.append("autofirma", isAutofirma);

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/requerimiento/v1/respuesta", {
        method: 'POST',
        body: postBody
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);
        if (res.hayError) {
            console.log("Error al procesar Requerimiento");
            // Mostrar Toast
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            toggleModal(MODAL_REQUERIMIENTO, false);

            window.location.search = urlParams.toString() + "&msg=1001"; //Force reload with updated params
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error)
    });
}

// MODAL RESPUESTA CONTROL Y GESTION
const loadModalRespControlGestion = (idControlGestion) => {
    const modalRespConGes = document.querySelector('#' + MODAL_RESPUESTACONTROLGESTION);

    const nombreProcedimiento = document.querySelector("#nombreProcedimiento").value;
    modalRespConGes.querySelector("#conGes_nomProc").value = nombreProcedimiento;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Cargando detalle del trámite...", "Espera, por favor.");

    fetch(contextPath + "/.rest/seguimiento/v1/controlGestion/detalle?" + new URLSearchParams({
        idControlGestion: idControlGestion,
        }), {
        method: 'GET'
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);

        const validResponse = !isEmpty(res) && !isEmpty(res.data) && !isEmpty(res.data.controlGestion);
        if (validResponse) {
            const controlGestionData = res.data.controlGestion[0];

            modalRespConGes.setAttribute('title-text', "Responder al trámite " + controlGestionData.codigo);
            modalRespConGes.dialogLabel = "Responder al trámite " + controlGestionData.codigo;
            modalRespConGes.querySelector("#conGes_codigo").value = controlGestionData.codigo;
            modalRespConGes.querySelector("#conGes_id").value = controlGestionData.id;

            modalRespConGes.querySelector("#conGes_motivo").value = controlGestionData.motivo;
            const fechaIni = new Date(controlGestionData.fechaInicioSolicitud);
            modalRespConGes.querySelector("#conGes_fechaIni").value = DATE_FORMATTER.format(fechaIni);
            if (controlGestionData.fechaFinSolicitud) {
                const fechaCad = new Date(controlGestionData.fechaFinSolicitud);
                modalRespConGes.querySelector("#conGes_fechaCad").value = DATE_FORMATTER.format(fechaCad);
            } else {
                modalRespConGes.querySelector("#conGes_fechaCad").hidden = true;
            }

            toggleModal(MODAL_RESPUESTACONTROLGESTION, true);
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        console.error(error)
    });
}

const evalAndSendControlGestion = (isClave, idCliente, nifSol) => {
    const modal = document.querySelector('#' + MODAL_RESPUESTACONTROLGESTION);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendControlGestionResponse(isClave, idCliente, nifSol);
}

const sendControlGestionResponse = async (isClave, idCliente, nifSol, isCallbackFromClave) => {
    const urlSearch = window.location.search;
    const urlParams = new URLSearchParams(urlSearch);
    const idExp = urlParams.get('id');

    const modal = document.querySelector('#' + MODAL_RESPUESTACONTROLGESTION);
    let idTramite = modal.querySelector("#conGes_id").value;
    const tipoFirma = modal.querySelector("#controlGestion_firmaTipo").value;
    let isAutofirma = tipoFirma === 'autofirma';

    let responseList = [];
    if (!isCallbackFromClave) {
        // Obtener respuestas de los campos de la modal de Control y Gestión
        const elementsSelectors = [
            "div.formContainer.formTramite:not([hidden]) .form-control:not([hidden])",
            "div.formContainer.formTramite .form-control.form-data"
        ]
        const controls = modal.querySelectorAll(elementsSelectors.join(", "));
        try {
            responseList = await handleRespuestasFormularios(controls, idCliente, nifSol, isAutofirma);
        } catch (error) {
            // Abort SendRequest
            return;
        }
    }

    // Revalidacion con Clave Auth (si es usuario Clave y no ha seleccionado Autofirma)
    if (!isAutofirma && isClave) {
        if (isCallbackFromClave) {
            // Recover session data (Callback from Clave)
            const sessionControlGes = sessionStorage.getItem("controlGestionPending");
            const controlGesRequest = JSON.parse(sessionControlGes);
            idTramite = controlGesRequest.idTramite;
            responseList = controlGesRequest.respuestas;

            // Remove pending data
            sessionStorage.removeItem("controlGestionPending");
            urlParams.delete('signValidation');
            urlParams.delete('signType');
        } else {
            // Save data to session (Redirect to Clave)
            const requestData = {
                "idTramite": idTramite,
                "respuestas": responseList
            }
            sessionStorage.setItem("controlGestionPending", JSON.stringify(requestData));

            window.location.href = CLAVE_VALIDATE_URL + encodeURIComponent(window.location.href + "&signType=controlGestion");
            return;
        }
    }


    const postBody = new URLSearchParams();
    postBody.append("idExpediente", idExp);
    postBody.append("idTramite", idTramite);
    postBody.append("ciudadano", nifSol);
    postBody.append("respuestas", JSON.stringify(responseList));
    postBody.append("autofirma", isAutofirma);

    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/seguimiento/v1/respuesta", {
        method: 'POST',
        body: postBody
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        if (res.hayError || res.error) {
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', '' + mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            toggleModal(MODAL_RESPUESTACONTROLGESTION, false);
            window.location.search = urlParams.toString() + "&msg=1001";
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
};


const IDS_CAMPOS_PAGO = Object.freeze({
    TIPO_PAGO: '22_2',
    ENTIDAD_CUENTA: '23_12',
    DOC_ADJUNTO: '8_3',
    ENTIDAD_TARJETA: '23_14',
    CODIGO_NRC: '27_18',
    FECHA_NRC: '18_19',
    NUM_CUENTA: '16_21',
    ENTIDAD_NRC: '23_17',
    NUM_TARJETA: '25_15',
    FECHA_CADUCIDAD: '26_20',
    ID_CONCEPTO_TASA: '11_22'
})

// MODAL REQUERIMIENTO PAGO
const loadModalRequerimientoPago = (idRequerimiento, modoLectura) => {
    const modalRequePago = document.querySelector('#' + MODAL_REQUERIMIENTOPAGO);

    const nombreProcedimiento = document.querySelector("#nombreProcedimiento").value;
    modalRequePago.querySelector("#requepa_nomProc").value = nombreProcedimiento;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Cargando detalle del trámite...", "Espera, por favor.");

    fetch(contextPath + "/.rest/requerimientoPago/v1/detalle?" + new URLSearchParams({
            idRequerimiento: idRequerimiento,
        }), {
        method: 'GET'
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);

        const validResponse = !isEmpty(res) && !isEmpty(res.data) && !isEmpty(res.data.requerimientoEpago);
        if (validResponse) {
            const requerimientoDataPago = res.data.requerimientoEpago;

            modalRequePago.setAttribute('title-text', "Responder al requerimiento de pago " + requerimientoDataPago.codigo);
            modalRequePago.dialogLabel = "Responder al requerimiento " + requerimientoDataPago.codigo;
            modalRequePago.querySelector("#requepa_codigo").value = requerimientoDataPago.codigo;
            modalRequePago.querySelector("#requepa_id").value = requerimientoDataPago.id;

            modalRequePago.querySelector("#requepa_motivo").value = requerimientoDataPago.motivo;
            modalRequePago.querySelector("#requepa_plazo").value = requerimientoDataPago.diasSuspension + " días";
            const fechaIni = new Date(requerimientoDataPago.fechaInicio);
            modalRequePago.querySelector("#requepa_fechaIni").value = DATE_FORMATTER.format(fechaIni);
            if (requerimientoDataPago.fechaFinalizacion) {
                const fechaCad = new Date(requerimientoDataPago.fechaFinalizacion);
                modalRequePago.querySelector("#requepa_fechaCad").value = DATE_FORMATTER.format(fechaCad);
            } else {
                modalRequePago.querySelector("#requepa_fechaCad").hidden = true;
            }

            modalRequePago.querySelector("#requepa_tasa_nombre").value = requerimientoDataPago.tasa.concepto.concepto;
            modalRequePago.querySelector("#requepa_tasa_mensaje").innerHTML = requerimientoDataPago.tasa.concepto.descripcion;

            modalRequePago.querySelector("#requepa_tasa_modelo").value = requerimientoDataPago.tasa.modelo;
            modalRequePago.querySelector("#requepa_tasa_codigo").value = requerimientoDataPago.tasa.codigo;
            modalRequePago.querySelector("#requepa_tasa_importe").value = requerimientoDataPago.tasa.concepto.importe + ' €';
            modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.ID_CONCEPTO_TASA + ']').value = requerimientoDataPago.tasa.concepto.id;

            if (modoLectura) {
                const respuestaPago = res.data.respuestaPago;

                modalRequePago.setAttribute('title-text', "Detalle del requerimiento de pago " + requerimientoDataPago.codigo);

                const selectTipoPago = modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.TIPO_PAGO + ']');
                selectTipoPago.value = respuestaPago.tipoPago;
                // Force trigger changeEvent with new value of tipoPago
                const changeEvent = new CustomEvent('changeEvent', {'detail': respuestaPago.tipoPago});
                selectTipoPago.dispatchEvent(changeEvent);

                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.DOC_ADJUNTO + ']').hidden = true;
                const linkDocJust = modalRequePago.querySelector('#linkDocJust');
                if (respuestaPago.idJustificante) {
                    linkDocJust.to = contextPath + "/.rest/download/v1/descargaDocumento?id=" + respuestaPago.idJustificante + "&tipoDocumento=docExpedienteCiudadano";
                    linkDocJust.hidden = false;
                } else {
                    linkDocJust.hidden = true;
                }

                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.ENTIDAD_CUENTA + ']').value = respuestaPago.entidadBancaria;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.NUM_CUENTA + ']').value = respuestaPago.numeroCuenta;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.ENTIDAD_TARJETA + ']').value = respuestaPago.entidadBancaria;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.NUM_TARJETA + ']').value = respuestaPago.numeroTarjeta;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.FECHA_CADUCIDAD + ']').value = respuestaPago.fechaCaducidad;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.ENTIDAD_NRC + ']').value = respuestaPago.entidadBancaria;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.CODIGO_NRC + ']').value = respuestaPago.codigoNRC;
                modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.FECHA_NRC + ']').value = respuestaPago.fecha;

                modalRequePago.classList.add('readOnly');
                modalRequePago.querySelectorAll('#formPago .form-control').forEach(control => {
                    control.readonly = true;
                });

            } else {
                // Reset value of tipoPago
                const selectTipoPago = modalRequePago.querySelector('[id$=c' + IDS_CAMPOS_PAGO.TIPO_PAGO + ']');
                selectTipoPago.value = '';
                // Force trigger changeEvent with empty value of tipoPago
                const changeEvent = new CustomEvent('changeEvent', {'detail': ''});
                selectTipoPago.dispatchEvent(changeEvent);

                // Hide link used for Doc Just on readonly
                const linkDocJust = modalRequePago.querySelector('#linkDocJust');
                linkDocJust.to = '';
                linkDocJust.hidden = true;

                modalRequePago.classList.remove('readOnly');
                modalRequePago.querySelectorAll('#formPago .form-control').forEach(control => {
                    control.readonly = false;
                });
            }

            toggleModal(MODAL_REQUERIMIENTOPAGO, true);
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        console.error(error)
    });
}

const evalAndSendRequerimientoPago = (isClave, idCliente) => {
    const modal = document.querySelector('#' + MODAL_REQUERIMIENTOPAGO);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendRequerimientoPagoResponse(isClave, idCliente);
}

const sendRequerimientoPagoResponse = async (isClave, idCliente) => {
    const urlSearch = window.location.search;
    const urlParams = new URLSearchParams(urlSearch);
    const idExp = urlParams.get('id');

    const modal = document.querySelector('#' + MODAL_REQUERIMIENTOPAGO);
    let idReq = modal.querySelector("#requepa_id").value;
    let codigo = modal.querySelector("#requepa_codigo").value;

    // Gestión respuestas
    let responsesList = [];

    const controls = document.querySelectorAll("div.formContainer.formTramite:not([hidden]) .form-control:not([hidden]), div.formContainer.formTramite .form-control.form-data");
    for (const control of controls) {
        let campoData = control.extra;
        console.log(campoData);

        if (campoData) {
            switch (campoData.idTipoCampo) {
                case 8: // Files
                    try {
                        // Upload file list
                        const tipoEstructural = campoData.tipoEstructural;
                        const idDocumentsList = await uploadFiles(control.fileList, tipoEstructural, idCliente);
                        campoData.respuesta = idDocumentsList.join("; ");
                    } catch (error) {
                        // Error on Upload File. Abort GuardarBorrador
                        return;
                    }
                    break;
                case 18: // Fecha
                    campoData.respuesta = isEmpty(control.value) ? "" : control.value;
                    break;
                case 22: // Opción Pago
                    campoData.respuesta = Number(control.value);
                    break;
                default:
                    campoData.respuesta = control.value;
                    break;
            }

            responsesList.push(campoData);
        } else {
            console.error(control.label + " no extra " + control.id);
        }
    };
    console.warn(responsesList);

    const postBody = new URLSearchParams();
    postBody.append("idExpediente", idExp);
    postBody.append("idRequerimiento", idReq);
    postBody.append("codigo", codigo);
    postBody.append("respuestas", JSON.stringify(responsesList));

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/requerimientoPago/v1/respuesta", {
        method: 'POST',
        body: postBody
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);
        if (res.hayError) {
            console.log("Error al procesar Requerimiento");
            // Mostrar Toast
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            toggleModal(MODAL_REQUERIMIENTOPAGO, false);

            showNotification('success', 'Tu petición se ha completado correctamente.');
            window.location.search = urlParams.toString() + "&msg=1001"; //Force reload with updated params + sucess message
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error)
    });
}

// MODAL PRUEBA
const loadModalPrueba = (idPrueba) => {
    const modalPru = document.querySelector('#' + MODAL_PRUEBA);

    const nombreProcedimiento = document.querySelector("#nombreProcedimiento").value;
    modalPru.querySelector("#pru_nomProc").value = nombreProcedimiento;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Cargando detalle del trámite...", "Espera, por favor.");

    fetch(contextPath + "/.rest/prueba/v1/detalle?" + new URLSearchParams({
            idPrueba: idPrueba,
        }), {
        method: 'GET'
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);

        const validResponse = !isEmpty(res) && !isEmpty(res.data) && !isEmpty(res.data.prueba);
        if (validResponse) {
            const pruebaData = res.data.prueba[0];

            modalPru.setAttribute('title-text', "Responder a la solicitud de pruebas " + pruebaData.codigo);
            modalPru.dialogLabel = "Responder a la solicitud de pruebas " + pruebaData.codigo;
            modalPru.querySelector("#pru_codigo").value = pruebaData.codigo;
            modalPru.querySelector("#pru_id").value = pruebaData.id;

            modalPru.querySelector("#pru_motivo").value = pruebaData.motivo;
            modalPru.querySelector("#pru_plazo").value = pruebaData.diasSuspension + " días";
            const fechaIni = new Date(pruebaData.fechaInicio);
            modalPru.querySelector("#pru_fechaIni").value = DATE_FORMATTER.format(fechaIni);
            if (pruebaData.fechaFinalizacion) {
                const fechaCad = new Date(pruebaData.fechaFinalizacion);
                modalPru.querySelector("#pru_fechaCad").value = DATE_FORMATTER.format(fechaCad);
            } else {
                modalPru.querySelector("#pru_fechaCad").hidden = true;
            }

            toggleModal(MODAL_PRUEBA, true);
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        console.error(error)
    });
}

const evalAndSendPrueba = (isClave, idCliente, nifSol) => {
    const modal = document.querySelector('#' + MODAL_PRUEBA);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendPruebaResponse(isClave, idCliente, nifSol);
}

const sendPruebaResponse = async (isClave, idCliente, nifSol, isCallbackFromClave) => {
    const urlSearch = window.location.search;
    const urlParams = new URLSearchParams(urlSearch);
    const idExp = urlParams.get('id');

    const modal = document.querySelector('#' + MODAL_PRUEBA);
    let idPrueba = modal.querySelector("#pru_id").value;
    let codigo = modal.querySelector("#pru_codigo").value;
    const tipoFirma = modal.querySelector("#pru_firmaTipo").value;
    let isAutofirma = tipoFirma === 'autofirma';

    let responseList = [];
    if (!isCallbackFromClave) {
        // Obtener respuestas de los campos del modal de Pruebas
        const elementsSelectors = [
            "div.formContainer.formTramite:not([hidden]) .form-control:not([hidden])",
            "div.formContainer.formTramite .form-control.form-data"
        ]
        const controls = modal.querySelectorAll(elementsSelectors.join(", "));
        try {
            responseList = await handleRespuestasFormularios(controls, idCliente, nifSol, isAutofirma);
        } catch (error) {
            // Abort SendRequest
            return;
        }
    }

    // Revalidacion con Clave Auth (si es usuario Clave y no ha seleccionado Autofirma)
    if (!isAutofirma && isClave) {
        if (isCallbackFromClave) {
            // Recover session data (Callback from Clave)
            const sessionPruebas = sessionStorage.getItem("pruebaPending");
            const controlPruebaRequest = JSON.parse(sessionPruebas);
            idPrueba = controlPruebaRequest.idPrueba;
            codigo = controlPruebaRequest.codigo;
            responseList = controlPruebaRequest.respuestas;

            // Remove pending data
            sessionStorage.removeItem("pruebaPending");
            urlParams.delete('signValidation');
            urlParams.delete('signType');
        } else {
            // Save data to session (Redirect to Clave)
            const requestData = {
                "codigo": codigo,
                "idPrueba": idPrueba,
                "respuestas": responseList
            }
            sessionStorage.setItem("pruebaPending", JSON.stringify(requestData));

            window.location.href = CLAVE_VALIDATE_URL + encodeURIComponent(window.location.href + "&signType=prueba");
            return;
        }
    }

    const postBody = new URLSearchParams();
    postBody.append("idExpediente", idExp);
    postBody.append("idPrueba", idPrueba);
    postBody.append("codigo", codigo);
    postBody.append("respuestas", JSON.stringify(responseList));
    postBody.append("autofirma", isAutofirma);

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/prueba/v1/respuesta", {
        method: 'POST',
        body: postBody
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((res) => {
        console.log(res);
        if (res.hayError) {
            console.log("Error al procesar Prueba");
            // Mostrar Toast
            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            toggleModal(MODAL_PRUEBA, false);

            window.location.search = urlParams.toString() + "&msg=1001"; //Force reload with updated params
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error)
    });
}

// MODAL DOCUMENTOS
const loadModalDocumentos = (datosTramite, documentosInicio, documentosRespuesta) => {
    const modalDoc = document.querySelector('#' + MODAL_DOCUMENTOS);

    modalDoc.querySelector("#doc_codigo").value = datosTramite.codigo || "";

    const estadoTag = modalDoc.querySelector("#doc_estado");
    estadoTag.type = datosTramite.estadoTagType;
    estadoTag.innerText = datosTramite.estadoTagLabel;

    modalDoc.querySelector("#doc_respuesta").value = datosTramite.respuesta || "";

    // Fecha de inicio
    if (datosTramite.fechaInicio) {
        modalDoc.querySelector("#doc_fechaIni").value = datosTramite.fechaInicio;
        modalDoc.querySelector("#doc_fechaIni").hidden = false;
    } else {
        modalDoc.querySelector("#doc_fechaIni").value = "";
        modalDoc.querySelector("#doc_fechaIni").hidden = true;
    }

    // Fecha de finalización
    if (datosTramite.fechaFinalizacion) {
        modalDoc.querySelector("#doc_fechaFin").value = datosTramite.fechaFinalizacion.replace("Z", "");
        modalDoc.querySelector("#doc_fechaFin").hidden = false;
    } else {
        modalDoc.querySelector("#doc_fechaFin").value = "";
        modalDoc.querySelector("#doc_fechaFin").hidden = true;
    }

    renderDocument(datosTramite, documentosInicio, documentosRespuesta);

    toggleModal(MODAL_DOCUMENTOS, true);

}

const renderDocument = (datosTramite, documentosInicio, documentosRespuesta) => {
    const contenedorInicioPrincipales = document.querySelector('#documentosInicioPrincipales');
    const contenedorInicioAdjuntos = document.querySelector('#documentosInicioAdjuntos');
    const bloqueInicioAdjuntos = contenedorInicioAdjuntos?.previousElementSibling; // el <p> "Adjuntos"
    const contenedorRespuestaPrincipales = document.querySelector('#documentosRespuestaPrincipales');
    const contenedorRespuestaAdjuntos = document.querySelector('#documentosRespuestaAdjuntos');
    const bloqueRespuesta = document.querySelector('#seccionRespuesta');
    const docRespuestaField = document.querySelector('#doc_respuesta');
    const bloqueRespuestaInput = docRespuestaField?.closest('.dnt-flex');
    const bloqueRespuestaAdjuntos = contenedorRespuestaAdjuntos?.previousElementSibling;
    const bloqueRespuestaPrincipales = contenedorRespuestaPrincipales?.previousElementSibling;

    // Limpia contenedores
    contenedorInicioPrincipales.innerHTML = '';
    contenedorInicioAdjuntos.innerHTML = '';
    contenedorRespuestaPrincipales.innerHTML = '';
    contenedorRespuestaAdjuntos.innerHTML = '';

    // Oculta por defecto los bloques condicionales
    contenedorInicioAdjuntos.style.display = 'none';
    bloqueInicioAdjuntos.style.display = 'none';
    bloqueRespuesta.style.display = 'none';
    bloqueRespuestaInput.style.display = 'none';
    bloqueRespuestaAdjuntos.style.display = 'none';
    contenedorRespuestaAdjuntos.style.display = 'none';
    bloqueRespuestaPrincipales.style.display = 'none';
    contenedorRespuestaPrincipales.style.display = 'none';

    const crearLinkDoc = (doc, nombreDoc) => {
        const link = document.createElement('dnt-link');
        link.setAttribute('type', 'block');
        link.setAttribute('size', 's');
        link.setAttribute('tag', 'a');
        link.setAttribute('text', nombreDoc);
        link.setAttribute('title-text', 'Visualizar documento');
        link.setAttribute('external', 'true');
        link.setAttribute('icon', 'File');
        link.setAttribute('icon-position', 'left');
        link.setAttribute('bold', 'true');

        const docTieneId = !!doc.id;
        link.setAttribute('disabled', docTieneId ? 'false' : 'true');

        const url = doc.esAC1
          ? `${CONTEXT_PATH}/.rest/download/v1/recuperaDocumento?id=${doc.id}`
          : `${CONTEXT_PATH}/.rest/download/v1/descargaDocumento?id=${doc.id}&tipoDocumento=docExpediente`;

        link.setAttribute('to', url);
        return link;
    };

    // ==== DOCUMENTOS DE INICIO ====
    if (documentosInicio.length > 0) {
        let indexAdjunto = 1;
        let hayAdjuntos = false;

        documentosInicio.forEach((doc) => {
            let nombreVisible;
            let nombreDoc = doc.nombre;

            if (datosTramite.tipo === "Alegación") {
                nombreVisible = doc.adjunto ? `Ver adjunto alegación ${indexAdjunto++}` : "Ver alegación";
            } else if (
                ((datosTramite.tipo === "Requerimiento" || datosTramite.tipo === "Prueba") &&
                 !["CREADO", "EXPIRADO", "RECHAZADO"].includes(datosTramite.estado)) ||
                !["Alegación", "Requerimiento", "Prueba", "Requerimiento de pago"].includes(datosTramite.tipo)
            ) {
                nombreVisible = doc.adjunto ? `Ver adjunto trámite ${indexAdjunto++}` : "Ver trámite";
            } else {
                nombreVisible = doc.adjunto ? `Ver adjunto inicio ${indexAdjunto++}` : "Documento de inicio";
            }

            const link = crearLinkDoc(doc, nombreDoc);
            if (doc.adjunto) {
                contenedorInicioAdjuntos.appendChild(link);
                hayAdjuntos = true;
            } else {
                contenedorInicioPrincipales.appendChild(link);
            }
        });

        // Mostrar sub-bloque "Adjuntos" solo si hay
        if (hayAdjuntos) {
            contenedorInicioAdjuntos.style.display = '';
            bloqueInicioAdjuntos.style.display = '';
        }
    }

    // ==== DOCUMENTOS DE RESPUESTA ====
    let hayDocsRespuesta = false;
    let hayPrincipalesRespuesta = false;
    let hayAdjuntosRespuesta = false;

    if (documentosRespuesta.length > 0) {
        let indexAdjunto = 1;
        documentosRespuesta.forEach((doc) => {
            let nombreVisible;
            let nombreDoc = doc.nombre;

            if (datosTramite.tipo === "Alegación") {
                nombreVisible = doc.adjunto ? `Ver adjunto respuesta tramitador ${indexAdjunto++}` : "Ver respuesta tramitador";
            } else if (
                ["PENDIENTE", "COMPLETADO"].includes(datosTramite.estado) &&
                ["Requerimiento", "Prueba"].includes(datosTramite.tipo)
            ) {
                nombreVisible = doc.adjunto ? `Ver adjunto respuesta ${indexAdjunto++}` : "Ver respuesta";
            } else {
                nombreVisible = doc.adjunto ? `Ver adjunto respuesta ${indexAdjunto++}` : "Documento de respuesta";
            }

            const link = crearLinkDoc(doc, nombreDoc);
            if (doc.adjunto) {
                contenedorRespuestaAdjuntos.appendChild(link);
                hayAdjuntosRespuesta = true;
            } else {
                contenedorRespuestaPrincipales.appendChild(link);
                hayPrincipalesRespuesta = true;
            }
        });
    }

    // Verificar contenido de campo de texto
    const valorRespuestaTexto = docRespuestaField?.value?.trim();
    const hayTextoRespuesta = !!valorRespuestaTexto;

    // Mostrar bloques si hay contenido
    if (hayTextoRespuesta || hayPrincipalesRespuesta || hayAdjuntosRespuesta) {
        bloqueRespuesta.style.display = '';
        if (hayTextoRespuesta) bloqueRespuestaInput.style.display = '';
        if (hayPrincipalesRespuesta) {
            bloqueRespuestaPrincipales.style.display = '';
            contenedorRespuestaPrincipales.style.display = '';
        }
        if (hayAdjuntosRespuesta) {
            bloqueRespuestaAdjuntos.style.display = '';
            contenedorRespuestaAdjuntos.style.display = '';
        }
    } else {
        bloqueRespuesta.style.display = 'none';
    }
};

const handleClaveCallbackForTramite = (nifSol, idCliente) => {
    const urlParams = new URLSearchParams(window.location.search);
    const hasSignValidation = urlParams.get('signValidation');
    const signType = urlParams.get('signType');
    if (hasSignValidation && signType) {
        switch (signType) {
            case 'alegacion':
                sendAlegacionRequest(true, idCliente, nifSol, true);
                break;
            case 'requerimiento':
                sendRequerimientoResponse(true, idCliente, nifSol, true);
                break;
            case 'requerimientoPago':
                sendRequerimientoPagoResponse(true, idCliente);
                break;
            case 'prueba':
                sendPruebaResponse(true, idCliente, nifSol, true);
                break;
            case 'aportarDocumentacion':
                sendAportarDocuRequest(true, idCliente, nifSol, true);
                break;
            case 'controlGestion':
                sendControlGestionResponse(true, idCliente, nifSol, true);
                break;
            default:
                showNotification('error', 'Se ha producido un error al procesar la firma', 'Vuelve a intentarlo más tarde');
                break;
        }
    }
}

// MODAL COMPARECENCIA
const loadModalComparecencia = (id) => {
    const modalComp = document.querySelector('#' + MODAL_COMPARECENCIA);

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Cargando detalle de la notificación...", "Espera, por favor.");

    fetch(contextPath + "/.rest/notificacion/v1/detalle?" + new URLSearchParams({
            id: id,
        }), {
        method: 'GET'
    }).then((response) => {
        toggleLoadingSpinner(false);
        return response.json();
    }).then((notificacionData) => {
        const validResponse = !isEmpty(notificacionData) && !isEmpty(notificacionData.id);
        if (validResponse) {
            modalComp.setAttribute('title-text', "Firmar acuse de recibo asociado al expediente " + notificacionData.identificador);
            modalComp.dialogLabel = "Firmar acuse de recibo asociado al expediente " + notificacionData.identificador;
            modalComp.querySelector("#notif_id").value = notificacionData.id;
            modalComp.querySelector("#tipo_notif").value = notificacionData.tipo;
            modalComp.querySelector("#codigo_notif").value = notificacionData.identificador;
            modalComp.querySelector("#notif_concepto").value = notificacionData.concepto;
            modalComp.querySelector("#concepto_notif").innerText = notificacionData.concepto;
            const fechaEmi = new Date(notificacionData.fechaEmision);
            modalComp.querySelector("#fecha_notif").innerText = DATE_FORMATTER.format(fechaEmi);

            toggleModal(MODAL_COMPARECENCIA, true);
        } else {
            showNotification('error', 'Se ha producido un error al cargar la notificación');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);
        console.error(error)
    });
}

const evalAndSendComparecencia = (aceptada) => {
    const modal = document.querySelector('#' + MODAL_COMPARECENCIA);
    const isCurrentFormValid = evaluateValidForm(modal);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    const idNotificacion = modal.querySelector("#notif_id").value;
    changeNotificationStatus(idNotificacion, aceptada, true);
}

const changeNotificationStatus = (id, aceptada, esNotificacion, idDocumento) => {
    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Este proceso puede tardar varios minutos. Por favor, espera su finalización sin cerrar esta pantalla del navegador.");

    fetch(contextPath + "/.rest/notificacion/v1/comparecencia?" + new URLSearchParams({
            idNotificacion: id,
            aceptada: aceptada
        }), {
        method: 'POST'
    }).then((response) => {
        return response.json();
    }).then((res) => {
        console.log(res);
        if (res.hayError) {
            // Mostrar Toast
            toggleLoadingSpinner(false);

            const mensajeError = getMensajeError(res.codigoError) || res.mensajeError;
            showNotification('error', ''+ mensajeError + ' (Código de error: ' + res.codigoError + ')', '');
        } else {
            // Response OK
            toggleLoadingSpinner(true, "Actualizando listado de notificaciones...", "Espera, por favor.");

            if (esNotificacion) {
                // Cerramos modal de comparecencia de notificaciones
                toggleModal(MODAL_COMPARECENCIA, false);

                const urlParams = new URLSearchParams(window.location.search);
                urlParams.set('msg', 1001); // Success notification on reload

                window.location.search = urlParams.toString(); // Force reload with updated params + sucess message
            } else {
                // Abrimos documento de comunicación en nueva ventana
                const docURL = contextPath + "/.rest/download/v1/descargaDocumento?id=" + idDocumento + "&tipoDocumento=docExpediente";
                window.open(docURL, '_blank');

                window.location.reload();
            }
        }

    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error)
    });
}

const markComunicacionLeida = (idComunicacion, idDoc) => {
    // Marca comunicación como leída (comparecida)
    changeNotificationStatus(idComunicacion, true, false, idDoc);
}

// BORRADORES
const deleteBorrador = (id) => {
    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Espera, por favor.");

    fetch(contextPath + "/.rest/formulario/v1/eliminarBorrador?" + new URLSearchParams({
            idBorrador: id,
        }), {
        method: 'POST'
    }).then((response) => {
        if (response.ok) {
            const urlParams = new URLSearchParams(window.location.search);
            urlParams.set('msg', 1001); // Success notification on reload

            window.location.search = urlParams.toString(); // Force reload with updated params + sucess message
        } else {
            showNotification('error', 'Se ha producido un error al eliminar el borrador', 'Vuelve a intentarlo más tarde');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error)
    });
}


const DocType = Object.freeze({
    REQUERIMIENTO: 1,
    // REQUERIMIENTO_ADJUNTO: Aún no existe,
    REQUERIMIENTO_RESPUESTA: 12,
    REQUERIMIENTO_RESPUESTA_ADJUNTO: 53,
    PRUEBA: 7,
    // PRUEBA_ADJUNTO: Aún no existe,
    PRUEBA_RESPUESTA: 13,
    PRUEBA_RESPUESTA_ADJUNTO: 52,
    MODIFICACION_PLAZO: 8,
    APORTAR_DOC: 43,
    APORTAR_DOC_ADJUNTO: 48,
    CONTROL_GESTION: 44,
    CONTROL_GESTION_ADJUNTO: 45,
    CONTROL_GESTION_RESPUESTA_ADJUNTO: 50,
    APORTAR_DOC_RESPUESTA: 47,
    APORTAR_DOC_RESPUESTA_ADJUNTO: 49,
    SUSPENSION: 9,
    INFORME: 6,
    AUDIENCIA: 3,
    INFORMACION_PUBLICA: 4,
    ALEGACION: 5,
    ALEGACION_ADJUNTO: 54,
    ALEGACION_RESPUESTA: 28,
    APORTAR_DOC_EXPEDIENTE: 57,
    APORTAR_DOC_RESPUESTA_EXPEDIENTE: 58,
    APORTAR_DOC_ADJUNTO_EXPEDIENTE: 59,
    APORTAR_DOC_RESPUESTA_ADJUNTO_EXPEDIENTE: 60,
    // ALEGACION_RESPUESTA_ADJUNTO: Aún no existe
})

const getTramiteDoc = (tipo, docList) => {
    console.log('%cgetTramiteDoc: tipo => ' + tipo, 'color: lightgreen');
    console.log('docList => ', docList);

    let docTypeFilter;
    switch (tipo) {
        case 'Requerimiento':
            docTypeFilter = DocType.REQUERIMIENTO;
            break;
        case 'Prueba':
            docTypeFilter = DocType.PRUEBA;
            break;
        case 'Modificación de plazo':
            docTypeFilter = DocType.MODIFICACION_PLAZO;
            break;
        case 'Suspension':
            docTypeFilter = DocType.SUSPENSION;
            break;
        case 'Informe':
            docTypeFilter = DocType.INFORME;
            break;
        case 'Audiencia':
            docTypeFilter = DocType.AUDIENCIA;
            break;
        case 'Información Pública':
            docTypeFilter = DocType.INFORMACION_PUBLICA;
            break;
        case 'Alegación':
            docTypeFilter = DocType.ALEGACION;
            break;
        case 'Control y gestión':
            docTypeFilter = DocType.CONTROL_GESTION;
            break;
        case 'Aportar documentación':
            docTypeFilter = DocType.APORTAR_DOC_EXPEDIENTE;
            break;
        case 'Aportar documentación seguimiento':
            docTypeFilter = DocType.APORTAR_DOC;
            break;
    }

    const docFind = docList?.find(doc => doc.tipo == docTypeFilter);
    console.log(docFind);
    return docFind;
}

const getAdjuntosTramiteDoc = (tipo, docList) => {
    console.log('%cgetAdjuntosTramiteDoc: tipo => ' + tipo, 'color: lightgreen');
    console.log('docList => ', docList);

    let docTypeFilter;
    switch (tipo) {
        case 'Alegación':
            docTypeFilter = DocType.ALEGACION_ADJUNTO;
            break;
        case 'Control y gestión':
            docTypeFilter = DocType.CONTROL_GESTION_ADJUNTO;
            break;
        case 'Aportar documentación':
            docTypeFilter = DocType.APORTAR_DOC_ADJUNTO_EXPEDIENTE;
            break;
        case 'Aportar documentación seguimiento':
            docTypeFilter = DocType.APORTAR_DOC_ADJUNTO;
            break;

    }

    const docsFiltered = docList?.filter(doc => doc.tipo === docTypeFilter) || [];
    console.log(docsFiltered);
    return docsFiltered;
}

const getRespuestaTramiteDoc = (tipo, docList) => {
    console.log('%cgetRespuestaTramiteDoc: tipo => ' + tipo, 'color: deepskyblue');
    console.log('docList => ', docList);

    let docTypeFilter;
    switch (tipo) {
        case 'Requerimiento':
            docTypeFilter = DocType.REQUERIMIENTO_RESPUESTA;
            break;
        case 'Prueba':
            docTypeFilter = DocType.PRUEBA_RESPUESTA;
            break;
        case 'Alegación':
            docTypeFilter = DocType.ALEGACION_RESPUESTA;
            break;
        case 'Aportar documentación':
            docTypeFilter = DocType.APORTAR_DOC_RESPUESTA_EXPEDIENTE;
            break;
        case 'Aportar documentación seguimiento':
            docTypeFilter = DocType.APORTAR_DOC_RESPUESTA;
            break;
    }

    const docFind = docList?.find(doc => doc.tipo == docTypeFilter);
    console.log(docFind);
    return docFind;
}

const getAdjuntosRespuestaTramiteDoc = (tipo, docList) => {
    console.log('%cgetAdjuntosRespuestaTramiteDoc: tipo => ' + tipo, 'color: lightgreen');
    console.log('docList => ', docList);

    let docTypeFilter;
    switch (tipo) {
        case 'Requerimiento':
            docTypeFilter = DocType.REQUERIMIENTO_RESPUESTA_ADJUNTO;
            break;
        case 'Prueba':
            docTypeFilter = DocType.PRUEBA_RESPUESTA_ADJUNTO;
            break;
        case 'Control y gestión':
            docTypeFilter = DocType.CONTROL_GESTION_RESPUESTA_ADJUNTO;
            break;
        case 'Aportar documentación':
            docTypeFilter = DocType.APORTAR_DOC_RESPUESTA_ADJUNTO_EXPEDIENTE;
            break;
        case 'Aportar documentación seguimiento':
            docTypeFilter = DocType.APORTAR_DOC_RESPUESTA_ADJUNTO;
            break;

    }

    const docsFiltered = docList?.filter(doc => doc.tipo === docTypeFilter) || [];
    console.log(docsFiltered);
    return docsFiltered;
}
