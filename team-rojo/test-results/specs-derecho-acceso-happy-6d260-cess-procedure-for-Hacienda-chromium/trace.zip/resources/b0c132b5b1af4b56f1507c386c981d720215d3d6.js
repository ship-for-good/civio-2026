const foreignCitizen = () => {
    showNotification('error', 'No puedes acceder a este procedimiento', 'Este procedimiento solo es accesible con Cl@ve');
}

const evalAndSendPasswordRestore = (idCliente) => {
    const restore = document.querySelector('#resContraseña');
    const isCurrentFormValid = evaluateValidForm(restore);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendPasswordRestore(idCliente);
}

const sendPasswordRestore = async (idCliente) => {
    const formRestore = document.querySelector('#resContraseña');

    const identificador = formRestore.querySelector("#res_numIden").value;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Espera, por favor.");

    fetch(contextPath + "/.rest/usuario/v1/resetPassword?" + new URLSearchParams ({
            numeroIdentificacion: identificador,
            idCliente: idCliente
        }), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {
        console.log(response);
        return response;
    }).then((res) => {
        console.log(res);
        if (res.ok) {
            window.location.href = linkPrefix + "/usuarios/login?msg=1002";
        } else {
            console.log("Error al procesar...");
            toggleLoadingSpinner(false);
            // Mostrar Toast
            showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
}

const evalAndSendPasswordChange = (idCliente) => {
    const change = document.querySelector('#cambioContraseña');
    const isCurrentFormValid = evaluateValidForm(change);
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const token = urlParams.get('token');

    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    if (token) {
        sendPasswordChange(idCliente, token);
    } else {
        showNotification('error', 'Se ha producido un error durante el proceso');
    }
}

const sendPasswordChange = async (idCliente, token) => {
    const formCambio = document.querySelector('#cambioContraseña');

    const passwordControl = formCambio.querySelector("#cambio_pwd");
    const passwordConfirmControl = formCambio.querySelector("#cambio_pwdConf");

    // Validate password vs confirm password
    const passwordComparison = compareInputsValidation(passwordControl,
                                            passwordConfirmControl,
                                            "La confirmación de contraseña debe ser igual a la contraseña");

    if (!passwordComparison) {
        // Blocks continue when confirmations dont match
        return;
    }

    const password = passwordControl.value;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Espera, por favor.");

    fetch(contextPath + "/.rest/usuario/v1/changePassword?" + new URLSearchParams ({
            token: token,
            newPassword: password,
            idCliente: idCliente
        }), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {
        console.log(response);
        return response;
    }).then((res) => {
        console.log(res);
        if (res.ok) {
            window.location.href = linkPrefix + "/usuarios/login?msg=1001";
        } else {
            console.log("Error al procesar...");
            toggleLoadingSpinner(false);
            // Mostrar Toast
            showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
}

const evalAndSendLogin = (idCliente) => {
    const formLogin = document.querySelector("dnt-section.formLogin");
    const isCurrentFormValid = evaluateValidForm(formLogin);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendUserLogin(idCliente)
}

const sendUserLogin = async (idCliente) => {
    const formLogin = document.querySelector("dnt-section.formLogin");

    const usuario = formLogin.querySelector("#login_user").value;
    const password = formLogin.querySelector("#login_password").value;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Iniciando sesión...", "Espera, por favor.");

    let loginBody = {
        "password": password,
        "usuario": usuario,
        "idCliente": idCliente
    }

    console.warn(loginBody);

    fetch(contextPath + "/.rest/usuario/v1/login", {
        method: 'POST',
        body: JSON.stringify(loginBody),
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {
        console.log(response);
        return response;
    }).then((res) => {
        console.log(res);
        if (res.ok) {
            const queryString = window.location.search;
            const urlParams = new URLSearchParams(queryString);
            let returnUrl = urlParams.get('returnUrl');

            if (!returnUrl) {
                returnUrl = linkPrefix + "/";
            }
            window.location.href = returnUrl;
        } else {
            toggleLoadingSpinner(false);

            showNotification('error', 'Usuario o contraseña incorrectos');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Usuario o contraseña incorrectos');
        console.error(error)
    });
}

const evalAndSendActivate = (idCliente) => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const token = urlParams.get('token');

    if (token) {
        sendUserActive(idCliente, token);
    } else {
        showNotification('error', 'Error de activación', 'Se ha producido un error al activar tu cuenta. Vuelve a intentarlo más tarde.');
    }
}

const sendUserActive = (idCliente, token) => {
    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos activando tu cuenta...", "Espera, por favor.");

    fetch(contextPath + "/.rest/usuario/v1/activate?" + new URLSearchParams({
            token: token,
            idCliente: idCliente
        }), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {
        return response;
    }).then((res) => {
        console.log(res);
        if (res.ok) {
            window.location.href = linkPrefix + "/usuarios/login?msg=1003";
        } else {
            toggleLoadingSpinner(false);

            showNotification('error', 'Se ha producido un error al activar tu cuenta', 'Vuelve a intentarlo más tarde');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al activar tu cuenta', 'Vuelve a intentarlo más tarde');
        console.error(error)
    });
}

const evalAndSendAlta = (idCliente) => {
    const alta = document.querySelector('#altaExtran');
    const isCurrentFormValid = evaluateValidForm(alta);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendAltaRequest(idCliente);
}

const sendAltaRequest = async (idCliente) => {
    const formAlta = document.querySelector('#altaExtran');

    const identificador = formAlta.querySelector("#alta_numIden").value;
    const nombre = formAlta.querySelector("#alta_nombre").value;
    const primerApellido = formAlta.querySelector("#alta_primApe").value;
    const segundoApellido = formAlta.querySelector("#alta_seguApe").value;
    const procedimiento = formAlta.querySelector("#selec_procedimiento").value;

    const emailControl = formAlta.querySelector("#alta_email");
    const emailConfirmControl = formAlta.querySelector("#alta_emailConf");
    const passwordControl = formAlta.querySelector("#alta_pwd");
    const passwordConfirmControl = formAlta.querySelector("#alta_pwdConf");

    // Validate email vs confirm email
    const emailComparison = compareInputsValidation(emailControl,
                                            emailConfirmControl,
                                            "La confirmación de correo electrónico debe ser igual al correo electrónico");
    // Validate password vs confirm password
    const passwordComparison = compareInputsValidation(passwordControl,
                                            passwordConfirmControl,
                                            "La confirmación de contraseña debe ser igual a la contraseña");

    if (!emailComparison || !passwordComparison) {
        // Blocks continue when confirmations dont match
        return;
    }

    const email = emailControl.value;
    const password = passwordControl.value;

    let idDocumentsList;
    try {
        // Upload file list
        const documentoAltaList = formAlta.querySelector("dnt-file-uploader#fileExtranjero").fileList;
        idDocumentsList = await uploadFiles(documentoAltaList, null, idCliente);
    } catch (error) {
        // Error on Upload File. Abort SendRequest
        return;
    }


    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Espera, por favor.");

    let altaUsuarioBody = {
        "identificador": identificador,
        "nombre": nombre,
        "apellido1": primerApellido,
        "apellido2": segundoApellido,
        "email": email,
        "password": password,
        "procedimiento": procedimiento,
        "idDocumento": idDocumentsList[0]
    }

    console.warn(altaUsuarioBody);

    fetch(contextPath + "/.rest/usuario/v1/signUp?" + new URLSearchParams ({
            idCliente: idCliente
        }), {
        method: 'POST',
        body: JSON.stringify(altaUsuarioBody),
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {
        console.log(response);
        return response;
    }).then((res) => {
        console.log(res);
        if (res.ok) {
            window.location.href = linkPrefix + "/usuarios/login?msg=1001";
        } else {
            console.log("Error al procesar...");
            toggleLoadingSpinner(false);
            // Mostrar Toast
            showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
}

const evalAndSendModificacion = (idCliente) => {
    const modificacion = document.querySelector('#modDatosUsuario');
    const isCurrentFormValid = evaluateValidForm(modificacion);
    if (!isCurrentFormValid) {
        // Blocks continue when invalid
        return;
    }

    sendModificacionRequest(idCliente);
}

const sendModificacionRequest = async (idCliente) => {
    const formModificacion = document.querySelector('#modDatosUsuario');

    const nombre = formModificacion.querySelector("#mod_nom").value;
    const primerApellido = formModificacion.querySelector("#mod_primApe").value;
    const segundoApellido = formModificacion.querySelector("#mod_seguApe").value;
    const email = formModificacion.querySelector("#mod_direEmail").value;

    const usuario = formModificacion.querySelector("#mod_numIden").value;
    const password = formModificacion.querySelector("#mod_pwd").value;

    // Toggle loading overlay
    toggleLoadingSpinner(true, "Estamos procesando tu petición.", "Espera, por favor.");

    let modificacionUsuarioBody = {
        "usuario": usuario,
        "password": password,
        "nombre": nombre,
        "apellido1": primerApellido,
        "apellido2": segundoApellido,
        "email": email
    }

    console.warn(modificacionUsuarioBody);

    fetch(contextPath + "/.rest/usuario/v1/update?" + new URLSearchParams ({
            idCliente: idCliente
        }), {
        method: 'POST',
        body: JSON.stringify(modificacionUsuarioBody),
        headers: {
            'Content-Type': 'application/json;charset=UTF-8'
        }
    }).then((response) => {

        console.log(response);
        return response;
    }).then((res) => {
        console.log(res);
        if (res.ok) {
            if (window.location.href.toString().endsWith("?msg=1001")) {
                window.location.reload();
            } else {
                window.location.href += "?msg=1001";
            }
        } else {
            console.log("Error al procesar...");
            toggleLoadingSpinner(false);
            // Mostrar Toast
            showNotification('error', 'Se ha producido un error al modificar tus datos', 'Vuelve a intentarlo más tarde');
        }
    }).catch((error) => {
        toggleLoadingSpinner(false);

        showNotification('error', 'Se ha producido un error al procesar tu petición', 'Vuelve a intentarlo más tarde');
        console.error(error);
    });
}

const errorUserModify = () => {
    showNotification('error', 'No puedes acceder a este servicio', 'Este servicio solo es accesible para usuarios extranjeros');
}
